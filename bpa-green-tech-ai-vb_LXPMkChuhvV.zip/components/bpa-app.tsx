"use client";

import { BpaProvider, useBpa } from "@/contexts/bpa-context";
import { LoadingScreen, StorageNotice, ToastHost } from "@/components/bpa/pieces";
import { BottomNav } from "@/components/bpa/bottom-nav";
import { DashboardScreen } from "@/components/bpa/dashboard-screen";
import { TreesScreen } from "@/components/bpa/trees-screen";
import { ProjectsScreen } from "@/components/bpa/projects-screen";
import { IrrigationScreen } from "@/components/bpa/irrigation-screen";
import { CareLogScreen } from "@/components/bpa/carelog-screen";
import { AcceptanceScreen } from "@/components/bpa/acceptance-screen";
import { AssistantScreen } from "@/components/bpa/assistant-screen";
import { EnterpriseProvider } from "@/contexts/enterprise-context";
import { EnterpriseScreen } from "@/components/bpa/enterprise-screen";

function Shell() {
  const { ready, tab } = useBpa();
  if (!ready) return <LoadingScreen />;

  return (
    <div className="bpa-app-bg min-h-[100dvh]">
      <main key={tab} className="anim-fade-in">
        {tab === "dashboard" && <DashboardScreen />}
        {tab === "trees" && <TreesScreen />}
        {tab === "projects" && <ProjectsScreen />}
        {tab === "irrigation" && <IrrigationScreen />}
        {tab === "carelog" && <CareLogScreen />}
        {tab === "acceptance" && <AcceptanceScreen />}
        {tab === "assistant" && <AssistantScreen />}
        {(["personnel", "iot", "more", "company", "governance", "reports", "operations", "weather", "growth"] as const).includes(tab as never) && <EnterpriseScreen mode={tab as "personnel" | "iot" | "more" | "company" | "governance" | "reports" | "operations" | "weather" | "growth"} />}
      </main>
      {tab !== "assistant" && <div className="h-20" aria-hidden />}
      <BottomNav />
      <ToastHost />
      <StorageNotice />
    </div>
  );
}

export function BpaApp() {
  return (
    <BpaProvider>
      <EnterpriseProvider><Shell /></EnterpriseProvider>
    </BpaProvider>
  );
}
