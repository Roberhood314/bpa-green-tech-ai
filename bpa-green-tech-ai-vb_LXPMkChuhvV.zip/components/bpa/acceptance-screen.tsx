"use client";

import { useState } from "react";
import { Button, Card, Field, Icon, IconButton, Select, TextArea, TextInput, cx } from "./ui";
import { ConfirmButton, Overlay, Sheet, EmptyStateWrap } from "./shared";
import { ScreenHeader, DetailRow } from "./trees-screen";
import { useBpa, type AcceptanceInput } from "@/contexts/bpa-context";
import { APPROVAL_META, dateLabel, type Acceptance, type AcceptanceItem, type ApprovalStatus } from "@/lib/bpa/data";

export function AcceptanceScreen() {
  const { acceptances, projects, projectName, addAcceptance, updateAcceptance, setAcceptanceStatus, deleteAcceptance } = useBpa();
  const [openId, setOpenId] = useState<string | null>(null);
  const [editor, setEditor] = useState<{ mode: "new" } | { mode: "edit"; acc: Acceptance } | null>(null);

  const open = openId ? acceptances.find((a) => a.id === openId) : null;

  return (
    <div className="mx-auto max-w-xl px-4 pb-28 pt-4">
      <ScreenHeader title="Hồ sơ nghiệm thu" subtitle={`${acceptances.length} biên bản`} onAdd={() => setEditor({ mode: "new" })} addLabel="Tạo" />

      {acceptances.length === 0 ? (
        <EmptyStateWrap icon="clipboard" title="Chưa có biên bản" hint="Tạo biên bản nghiệm thu cho các hạng mục đã thực hiện." action={<Button onClick={() => setEditor({ mode: "new" })}><Icon name="plus" size={16} />Tạo biên bản</Button>} />
      ) : (
        <div className="flex flex-col gap-3">
          {acceptances.map((a) => {
            const m = APPROVAL_META[a.status];
            return (
              <button key={a.id} onClick={() => setOpenId(a.id)} className="bpa-press text-left">
                <Card className="p-4">
                  <div className="flex items-start justify-between gap-2">
                    <p className="min-w-0 flex-1 font-display text-[14px] font-bold text-[var(--bpa-ink)]">{a.name}</p>
                    <span className="flex-none rounded-full px-2.5 py-1 text-[11px] font-semibold" style={{ color: `var(${m.varName})`, backgroundColor: `var(${m.softVar})` }}>
                      {m.label}
                    </span>
                  </div>
                  <p className="mt-1 text-[12px] text-[var(--bpa-muted)]">{projectName(a.projectId)}</p>
                  <div className="mt-2 flex items-center gap-4 text-[12px] text-[var(--bpa-faint)]">
                    <span className="flex items-center gap-1"><Icon name="clipboard" size={13} />{a.items.length} hạng mục</span>
                    <span className="flex items-center gap-1"><Icon name="calendar" size={13} />{dateLabel(new Date(a.at).toISOString().slice(0, 10))}</span>
                  </div>
                </Card>
              </button>
            );
          })}
        </div>
      )}

      {open && (
        <AcceptanceDetail
          acc={open}
          projectLabel={projectName(open.projectId)}
          onClose={() => setOpenId(null)}
          onStatus={(s) => setAcceptanceStatus(open.id, s)}
          onEdit={() => {
            setEditor({ mode: "edit", acc: open });
            setOpenId(null);
          }}
          onDelete={() => {
            deleteAcceptance(open.id);
            setOpenId(null);
          }}
        />
      )}

      {editor && (
        <AcceptanceEditor
          initial={editor.mode === "edit" ? editor.acc : null}
          projects={projects}
          onClose={() => setEditor(null)}
          onSave={(input) => {
            if (editor.mode === "edit") updateAcceptance(editor.acc.id, input);
            else addAcceptance(input);
            setEditor(null);
          }}
        />
      )}
    </div>
  );
}

function PhotoSlot({ label }: { label: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-1.5 rounded-xl border border-dashed border-[var(--bpa-line)] bg-[var(--bpa-panel-2)] py-6 text-[var(--bpa-faint)]">
      <Icon name="leaf" size={22} />
      <span className="text-[11px] font-semibold">{label}</span>
    </div>
  );
}

function AcceptanceDetail({
  acc,
  projectLabel,
  onClose,
  onStatus,
  onEdit,
  onDelete,
}: {
  acc: Acceptance;
  projectLabel: string;
  onClose: () => void;
  onStatus: (s: ApprovalStatus) => void;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const m = APPROVAL_META[acc.status];
  return (
    <Overlay
      title="Biên bản nghiệm thu"
      onClose={onClose}
      footer={
        <div className="flex flex-col gap-2">
          {acc.status !== "da_duyet" && (
            <div className="flex items-center gap-2">
              <Button variant="primary" block onClick={() => onStatus("da_duyet")}>
                <Icon name="check" size={16} />
                Phê duyệt
              </Button>
              <Button variant="danger" block onClick={() => onStatus("tu_choi")}>
                <Icon name="close" size={16} />
                Từ chối
              </Button>
            </div>
          )}
          <div className="flex items-center gap-2">
            <Button variant="outline" block onClick={onEdit}>
              <Icon name="edit" size={16} />
              Chỉnh sửa
            </Button>
            <ConfirmButton onConfirm={onDelete} />
          </div>
        </div>
      }
    >
      <div className="flex items-start justify-between gap-2">
        <h2 className="font-display text-lg font-extrabold text-[var(--bpa-ink)]">{acc.name}</h2>
        <span className="flex-none rounded-full px-2.5 py-1 text-[11px] font-semibold" style={{ color: `var(${m.varName})`, backgroundColor: `var(${m.softVar})` }}>
          {m.label}
        </span>
      </div>

      <Card className="mt-3 divide-y divide-[var(--bpa-line-soft)]">
        <DetailRow icon="project" label="Dự án" value={projectLabel} />
        <DetailRow icon="pen" label="Người ký" value={acc.signer || "—"} />
        <DetailRow icon="calendar" label="Ngày lập" value={dateLabel(new Date(acc.at).toISOString().slice(0, 10))} />
      </Card>

      <h3 className="mb-2 mt-5 font-display text-base font-bold text-[var(--bpa-ink)]">Danh sách hạng mục</h3>
      <Card className="divide-y divide-[var(--bpa-line-soft)]">
        {acc.items.length === 0 ? (
          <p className="px-3.5 py-4 text-center text-sm text-[var(--bpa-muted)]">Chưa có hạng mục.</p>
        ) : (
          acc.items.map((it, i) => (
            <div key={i} className="flex items-center justify-between gap-3 px-3.5 py-3">
              <p className="min-w-0 flex-1 truncate text-[13px] font-semibold text-[var(--bpa-ink)]">{it.name}</p>
              <span className="bpa-nums text-[13px] font-bold text-[var(--bpa-green-deep)]">
                {it.quantity} {it.unit}
              </span>
            </div>
          ))
        )}
      </Card>

      <h3 className="mb-2 mt-5 font-display text-base font-bold text-[var(--bpa-ink)]">Hình ảnh nghiệm thu</h3>
      <div className="grid grid-cols-2 gap-3">
        <PhotoSlot label="Ảnh trước" />
        <PhotoSlot label="Ảnh sau" />
      </div>

      {acc.note && (
        <>
          <h3 className="mb-2 mt-5 font-display text-base font-bold text-[var(--bpa-ink)]">Ghi chú</h3>
          <Card className="p-3.5">
            <p className="bpa-pre text-[13px] text-[var(--bpa-muted)]">{acc.note}</p>
          </Card>
        </>
      )}

      <h3 className="mb-2 mt-5 font-display text-base font-bold text-[var(--bpa-ink)]">Chữ ký xác nhận</h3>
      <Card className="flex items-center justify-between p-4">
        <div>
          <p className="text-[11px] text-[var(--bpa-faint)]">Đại diện nghiệm thu</p>
          <p className="font-display text-lg font-bold italic text-[var(--bpa-green-deep)]">{acc.signer || "Chưa ký"}</p>
        </div>
        <Icon name="pen" size={26} />
      </Card>
    </Overlay>
  );
}

function AcceptanceEditor({
  initial,
  projects,
  onClose,
  onSave,
}: {
  initial: Acceptance | null;
  projects: ReturnType<typeof useBpa>["projects"];
  onClose: () => void;
  onSave: (input: AcceptanceInput) => void;
}) {
  const [name, setName] = useState(initial?.name ?? "");
  const [projectId, setProjectId] = useState(initial?.projectId ?? "");
  const [signer, setSigner] = useState(initial?.signer ?? "");
  const [note, setNote] = useState(initial?.note ?? "");
  const [items, setItems] = useState<AcceptanceItem[]>(initial?.items ?? [{ name: "", quantity: 1, unit: "cây" }]);

  const valid = name.trim().length > 0 && items.some((i) => i.name.trim());

  function setItem(i: number, patch: Partial<AcceptanceItem>) {
    setItems((prev) => prev.map((it, idx) => (idx === i ? { ...it, ...patch } : it)));
  }

  return (
    <Sheet title={initial ? "Chỉnh sửa biên bản" : "Tạo biên bản"} onClose={onClose}>
      <div className="flex flex-col gap-3">
        <Field label="Tên biên bản">
          <TextInput value={name} onChange={(e) => setName(e.target.value)} placeholder="Ví dụ: Nghiệm thu đợt 1" />
        </Field>
        <Field label="Dự án">
          <Select value={projectId} onChange={(e) => setProjectId(e.target.value)}>
            <option value="">Không gán dự án</option>
            {projects.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </Select>
        </Field>

        <div>
          <div className="mb-1.5 flex items-center justify-between">
            <span className="text-[13px] font-semibold text-[var(--bpa-ink)]">Hạng mục & khối lượng</span>
            <button
              className="bpa-press inline-flex items-center gap-1 rounded-lg bg-[var(--bpa-green-soft)] px-2.5 py-1 text-[12px] font-semibold text-[var(--bpa-green-deep)]"
              onClick={() => setItems((prev) => [...prev, { name: "", quantity: 1, unit: "cây" }])}
            >
              <Icon name="plus" size={14} />
              Thêm
            </button>
          </div>
          <div className="flex flex-col gap-2">
            {items.map((it, i) => (
              <div key={i} className="flex items-center gap-2">
                <TextInput value={it.name} onChange={(e) => setItem(i, { name: e.target.value })} placeholder="Tên hạng mục" className="flex-1" />
                <TextInput type="number" inputMode="numeric" value={it.quantity} onChange={(e) => setItem(i, { quantity: Number(e.target.value) })} className="w-16 text-center" />
                <TextInput value={it.unit} onChange={(e) => setItem(i, { unit: e.target.value })} className="w-16 text-center" />
                {items.length > 1 && (
                  <IconButton onClick={() => setItems((prev) => prev.filter((_, idx) => idx !== i))} aria-label="Xóa" className="!h-9 !w-9 text-[var(--bpa-error)]">
                    <Icon name="close" size={16} />
                  </IconButton>
                )}
              </div>
            ))}
          </div>
        </div>

        <Field label="Người ký / đại diện">
          <TextInput value={signer} onChange={(e) => setSigner(e.target.value)} placeholder="Họ tên" />
        </Field>
        <Field label="Ghi chú">
          <TextArea rows={2} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Nhận xét, kết luận nghiệm thu…" />
        </Field>

        <Button block disabled={!valid} onClick={() => onSave({ name, projectId: projectId || null, items: items.filter((i) => i.name.trim()), signer, note })}>
          <Icon name="check" size={16} />
          {initial ? "Lưu thay đổi" : "Tạo biên bản"}
        </Button>
      </div>
    </Sheet>
  );
}
