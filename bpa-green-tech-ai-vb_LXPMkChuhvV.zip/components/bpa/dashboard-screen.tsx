"use client";

import { useMemo } from "react";
import { Card, Eyebrow, Icon, Pill, SectionTitle, cx } from "./ui";
import { StatTile } from "./pieces";
import { useBpa } from "@/contexts/bpa-context";
import { formatInt, type Alert, type ModuleId } from "@/lib/bpa/data";

const ALERT_META: Record<Alert["kind"], { label: string; icon: Parameters<typeof Icon>[0]["name"]; tone: "error" | "water" | "warn" }> = {
  sau_benh: { label: "Sâu bệnh", icon: "bug", tone: "error" },
  thieu_nuoc: { label: "Thiếu nước", icon: "droplet", tone: "water" },
  thiet_bi: { label: "Thiết bị", icon: "warn", tone: "warn" },
};

const QUICK: Array<{ id: ModuleId; label: string; icon: Parameters<typeof Icon>[0]["name"]; desc: string }> = [
  { id: "trees", label: "Quản lý cây xanh", icon: "tree", desc: "Hồ sơ từng cây" },
  { id: "projects", label: "Dự án / công trình", icon: "project", desc: "Tiến độ thi công" },
  { id: "irrigation", label: "Tưới thông minh", icon: "droplet", desc: "Độ ẩm & lịch tưới" },
  { id: "carelog", label: "Nhật ký chăm sóc", icon: "log", desc: "Hoạt động hằng ngày" },
  { id: "acceptance", label: "Hồ sơ nghiệm thu", icon: "clipboard", desc: "Biên bản & phê duyệt" },
  { id: "assistant", label: "Green Assistant", icon: "robot", desc: "Trợ lý AI cây xanh" },
];

export function DashboardScreen() {
  const { trees, projects, zones, alerts, healthPct, activeZoneCount, setTab } = useBpa();
  const activeProjects = useMemo(() => projects.filter((p) => p.progress < 100).length, [projects]);

  return (
    <div className="mx-auto max-w-xl px-4 pb-28 pt-4">
      {/* hero */}
      <div className="bpa-hero-grad anim-fade-up relative overflow-hidden rounded-3xl p-5 text-[var(--bpa-on)]">
        <div className="pointer-events-none absolute -right-8 -top-10 opacity-20">
          <Icon name="leaf" size={140} />
        </div>
        <div className="relative flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/15">
            <Icon name="leaf" size={20} />
          </span>
          <div>
            <p className="font-display text-lg font-extrabold leading-tight">BPA Green Tech AI</p>
            <p className="text-[12px] text-white/80">Quản lý cây xanh & cảnh quan thông minh</p>
          </div>
        </div>
        <div className="relative mt-4 flex items-center gap-3 rounded-2xl bg-white/12 p-3">
          <div className="flex-1">
            <p className="text-[12px] text-white/80">Tỷ lệ cây khỏe toàn hệ thống</p>
            <p className="bpa-nums font-display text-3xl font-extrabold">{healthPct}%</p>
          </div>
          <div className="relative h-16 w-16">
            <svg viewBox="0 0 36 36" className="h-16 w-16 -rotate-90">
              <circle cx="18" cy="18" r="15.5" fill="none" stroke="rgba(255,255,255,0.22)" strokeWidth="4" />
              <circle
                cx="18"
                cy="18"
                r="15.5"
                fill="none"
                stroke="white"
                strokeWidth="4"
                strokeLinecap="round"
                strokeDasharray={`${(healthPct / 100) * 97.4} 97.4`}
              />
            </svg>
            <span className="absolute inset-0 flex items-center justify-center">
              <Icon name="leaf" size={20} />
            </span>
          </div>
        </div>
      </div>

      {/* stats */}
      <div className="mt-4 grid grid-cols-2 gap-3">
        <div className="anim-fade-up delay-1">
          <StatTile icon="tree" label="Cây đang quản lý" value={formatInt(trees.length)} tone="green" onClick={() => setTab("trees")} />
        </div>
        <div className="anim-fade-up delay-2">
          <StatTile icon="project" label="Công trình triển khai" value={formatInt(activeProjects)} sub={`${projects.length} dự án`} tone="lime" onClick={() => setTab("projects")} />
        </div>
        <div className="anim-fade-up delay-3">
          <StatTile icon="droplet" label="Khu vực đang tưới" value={formatInt(activeZoneCount)} sub={`${zones.length} khu vực`} tone="water" onClick={() => setTab("irrigation")} />
        </div>
        <div className="anim-fade-up delay-4">
          <StatTile icon="warn" label="Cảnh báo mới" value={formatInt(alerts.length)} tone="warn" onClick={() => document.getElementById("bpa-alerts")?.scrollIntoView({ behavior: "smooth" })} />
        </div>
      </div>

      {/* alerts */}
      <div id="bpa-alerts" className="mt-6">
        <SectionTitle>Cảnh báo mới</SectionTitle>
        {alerts.length === 0 ? (
          <Card className="flex items-center gap-3 p-4">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[var(--bpa-khoe-soft)] text-[var(--bpa-khoe)]">
              <Icon name="check" size={20} />
            </span>
            <p className="text-sm text-[var(--bpa-muted)]">Không có cảnh báo. Hệ thống đang hoạt động tốt.</p>
          </Card>
        ) : (
          <div className="flex flex-col gap-2.5">
            {alerts.map((a) => {
              const m = ALERT_META[a.kind];
              return (
                <Card key={a.id} className="flex items-start gap-3 p-3.5">
                  <span
                    className="mt-0.5 flex h-9 w-9 flex-none items-center justify-center rounded-xl"
                    style={{ color: `var(--bpa-${m.tone === "error" ? "error" : m.tone})`, backgroundColor: `var(--bpa-${m.tone === "error" ? "error" : m.tone}-soft)` }}
                  >
                    <Icon name={m.icon} size={18} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <Pill tone={m.tone}>{m.label}</Pill>
                      {a.severity === "high" && <span className="text-[11px] font-semibold text-[var(--bpa-error)]">Ưu tiên cao</span>}
                    </div>
                    <p className="mt-1 text-sm font-semibold text-[var(--bpa-ink)]">{a.message}</p>
                    <p className="text-[12px] text-[var(--bpa-muted)]">{a.detail}</p>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* quick access */}
      <div className="mt-6">
        <SectionTitle>Truy cập nhanh</SectionTitle>
        <div className="grid grid-cols-2 gap-3">
          {QUICK.map((q) => (
            <button
              key={q.id}
              onClick={() => setTab(q.id)}
              className={cx("bpa-press flex items-center gap-3 rounded-2xl border border-[var(--bpa-line)] bg-[var(--bpa-panel)] p-3.5 text-left")}
            >
              <span className="flex h-10 w-10 flex-none items-center justify-center rounded-xl bg-[var(--bpa-green-soft)] text-[var(--bpa-green-deep)]">
                <Icon name={q.icon} size={20} />
              </span>
              <div className="min-w-0">
                <p className="truncate text-[13px] font-bold text-[var(--bpa-ink)]">{q.label}</p>
                <p className="truncate text-[11px] text-[var(--bpa-faint)]">{q.desc}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6 flex items-center justify-center gap-1.5 text-[11px] text-[var(--bpa-faint)]">
        <Icon name="leaf" size={13} />
        <Eyebrow>BPA Green Tech · Vì một đô thị xanh</Eyebrow>
      </div>
    </div>
  );
}
