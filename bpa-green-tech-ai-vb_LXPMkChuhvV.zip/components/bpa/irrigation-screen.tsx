"use client";

import { useState } from "react";
import { Button, Card, Field, Icon, IconButton, ProgressBar, TextInput, cx } from "./ui";
import { ConfirmButton, Sheet, EmptyStateWrap } from "./shared";
import { ScreenHeader } from "./trees-screen";
import { useBpa, type ZoneInput } from "@/contexts/bpa-context";
import { ZONE_STATUS_META, formatInt, type Zone } from "@/lib/bpa/data";

function moistureTone(m: number): "green" | "lime" | "water" {
  if (m >= 60) return "green";
  if (m >= 40) return "lime";
  return "water";
}

export function IrrigationScreen() {
  const { zones, addZone, updateZone, setZoneStatus, toggleZone, deleteZone } = useBpa();
  const [editor, setEditor] = useState<{ mode: "new" } | { mode: "edit"; zone: Zone } | null>(null);

  const totalWater = zones.reduce((s, z) => s + z.waterLiters, 0);
  const active = zones.filter((z) => z.status === "tuoi").length;

  return (
    <div className="mx-auto max-w-xl px-4 pb-28 pt-4">
      <ScreenHeader title="Tưới thông minh" subtitle={`${zones.length} khu vực · ${active} đang tưới`} onAdd={() => setEditor({ mode: "new" })} addLabel="Khu vực" />

      <Card className="mb-4 flex items-center gap-3 bpa-lime-grad p-4 text-[var(--bpa-green-deep)]">
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/40">
          <Icon name="droplet" size={22} />
        </span>
        <div>
          <p className="text-[12px] font-semibold">Tổng lượng nước theo lịch</p>
          <p className="bpa-nums font-display text-2xl font-extrabold">{formatInt(totalWater)} lít</p>
        </div>
      </Card>

      {zones.length === 0 ? (
        <EmptyStateWrap icon="droplet" title="Chưa có khu vực tưới" hint="Thêm khu vực để quản lý độ ẩm và lịch tưới." action={<Button onClick={() => setEditor({ mode: "new" })}><Icon name="plus" size={16} />Thêm khu vực</Button>} />
      ) : (
        <div className="flex flex-col gap-3">
          {zones.map((z) => {
            const meta = ZONE_STATUS_META[z.status];
            return (
              <Card key={z.id} className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate font-display text-[15px] font-bold text-[var(--bpa-ink)]">{z.name}</p>
                    <span
                      className="mt-1 inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold"
                      style={{ color: `var(${meta.varName})`, backgroundColor: `var(${meta.softVar})` }}
                    >
                      <span className={cx("h-1.5 w-1.5 rounded-full", z.status === "tuoi" && "animate-pulse")} style={{ backgroundColor: `var(${meta.varName})` }} />
                      {meta.label}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <IconButton onClick={() => setEditor({ mode: "edit", zone: z })} aria-label="Sửa">
                      <Icon name="edit" size={18} />
                    </IconButton>
                  </div>
                </div>

                <div className="mt-3">
                  <div className="mb-1 flex items-center justify-between text-[12px]">
                    <span className="text-[var(--bpa-muted)]">Độ ẩm hiện tại</span>
                    <span className="bpa-nums font-bold text-[var(--bpa-ink)]">{Math.round(z.moisture)}%</span>
                  </div>
                  <ProgressBar value={z.moisture} tone={moistureTone(z.moisture)} />
                </div>

                <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                  <MiniStat icon="calendar" label="Lịch tưới" value={z.scheduleTime} />
                  <MiniStat icon="refresh" label="Thời lượng" value={`${z.durationMin}′`} />
                  <MiniStat icon="droplet" label="Lượng nước" value={`${formatInt(z.waterLiters)}l`} />
                </div>

                <div className="mt-3 flex items-center gap-2">
                  {z.status === "loi" ? (
                    <Button variant="danger" block onClick={() => setZoneStatus(z.id, "tam_dung")}>
                      <Icon name="warn" size={16} />
                      Đặt lại thiết bị
                    </Button>
                  ) : (
                    <Button variant={z.status === "tuoi" ? "solid" : "primary"} block onClick={() => toggleZone(z.id)}>
                      <Icon name={z.status === "tuoi" ? "pause" : "play"} size={16} />
                      {z.status === "tuoi" ? "Tạm dừng tưới" : "Bắt đầu tưới"}
                    </Button>
                  )}
                  <ConfirmButton onConfirm={() => deleteZone(z.id)} />
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {editor && (
        <ZoneEditor
          initial={editor.mode === "edit" ? editor.zone : null}
          onClose={() => setEditor(null)}
          onSave={(input) => {
            if (editor.mode === "edit") updateZone(editor.zone.id, input);
            else addZone(input);
            setEditor(null);
          }}
        />
      )}
    </div>
  );
}

function MiniStat({ icon, label, value }: { icon: Parameters<typeof Icon>[0]["name"]; label: string; value: string }) {
  return (
    <div className="rounded-xl bg-[var(--bpa-panel-2)] px-2 py-2">
      <span className="mx-auto mb-1 flex h-7 w-7 items-center justify-center rounded-lg text-[var(--bpa-green-deep)]">
        <Icon name={icon} size={15} />
      </span>
      <p className="bpa-nums text-[13px] font-bold text-[var(--bpa-ink)]">{value}</p>
      <p className="text-[10.5px] text-[var(--bpa-faint)]">{label}</p>
    </div>
  );
}

function ZoneEditor({ initial, onClose, onSave }: { initial: Zone | null; onClose: () => void; onSave: (input: ZoneInput) => void }) {
  const [name, setName] = useState(initial?.name ?? "");
  const [moisture, setMoisture] = useState(initial?.moisture ?? 50);
  const [scheduleTime, setScheduleTime] = useState(initial?.scheduleTime || "06:00");
  const [durationMin, setDurationMin] = useState(initial?.durationMin ?? 15);
  const [waterLiters, setWaterLiters] = useState(initial?.waterLiters ?? 200);

  const valid = name.trim().length > 0;

  return (
    <Sheet title={initial ? "Chỉnh sửa khu tưới" : "Thêm khu tưới"} onClose={onClose}>
      <div className="flex flex-col gap-3">
        <Field label="Tên khu vực">
          <TextInput value={name} onChange={(e) => setName(e.target.value)} placeholder="Ví dụ: A - Lối vào" />
        </Field>
        <Field label={`Độ ẩm hiện tại: ${moisture}%`}>
          <input type="range" min={0} max={100} value={moisture} onChange={(e) => setMoisture(Number(e.target.value))} className="w-full accent-[var(--bpa-water)]" />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Giờ tưới">
            <TextInput type="time" value={scheduleTime} onChange={(e) => setScheduleTime(e.target.value)} />
          </Field>
          <Field label="Thời lượng (phút)">
            <TextInput type="number" inputMode="numeric" value={durationMin} onChange={(e) => setDurationMin(Number(e.target.value))} />
          </Field>
        </div>
        <Field label="Lượng nước (lít)">
          <TextInput type="number" inputMode="numeric" value={waterLiters} onChange={(e) => setWaterLiters(Number(e.target.value))} />
        </Field>
        <Button block disabled={!valid} onClick={() => onSave({ name, moisture, scheduleTime, durationMin, waterLiters })}>
          <Icon name="check" size={16} />
          {initial ? "Lưu thay đổi" : "Thêm khu tưới"}
        </Button>
      </div>
    </Sheet>
  );
}
