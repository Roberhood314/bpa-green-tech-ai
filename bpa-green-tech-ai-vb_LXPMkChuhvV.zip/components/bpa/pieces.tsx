"use client";

import { useState, type ReactNode } from "react";
import { cx, Icon, IconButton, Spinner } from "./ui";
import { useBpa, type Toast } from "@/contexts/bpa-context";
import { HEALTH_META, type HealthId } from "@/lib/bpa/data";

export function LoadingScreen() {
  return (
    <div className="bpa-app-bg flex min-h-[100dvh] flex-col items-center justify-center gap-4 px-6 text-center">
      <span className="flex h-16 w-16 items-center justify-center rounded-3xl bpa-hero-grad text-[var(--bpa-on)] shadow-lg anim-pop">
        <Icon name="leaf" size={32} />
      </span>
      <div className="flex items-center gap-2 text-[var(--bpa-muted)]">
        <Spinner size={18} />
        <span className="text-sm font-medium">Đang tải dữ liệu cây xanh…</span>
      </div>
    </div>
  );
}

export function StorageNotice() {
  const { storageTrouble } = useBpa();
  if (!storageTrouble) return null;
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-24 z-[210] flex justify-center px-4">
      <div className="anim-toast pointer-events-auto flex items-center gap-2 rounded-full border border-[var(--bpa-warn)] bg-[var(--bpa-warn-soft)] px-4 py-2 text-[12px] font-semibold text-[var(--bpa-warn)] shadow-sm">
        <Icon name="refresh" size={14} />
        Đang lưu vào tài khoản Pi của bạn…
      </div>
    </div>
  );
}

export function ToastHost() {
  const { toasts } = useBpa();
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-24 z-[200] flex flex-col items-center gap-2 px-4">
      {toasts.map((t: Toast) => {
        const tone =
          t.tone === "ok"
            ? { c: "--bpa-khoe", s: "--bpa-khoe-soft" }
            : t.tone === "warn"
              ? { c: "--bpa-warn", s: "--bpa-warn-soft" }
              : { c: "--bpa-green-deep", s: "--bpa-green-soft" };
        return (
          <div
            key={t.id}
            className="anim-toast flex max-w-sm items-center gap-2 rounded-full px-4 py-2 text-[13px] font-semibold shadow-sm"
            style={{ color: `var(${tone.c})`, backgroundColor: `var(${tone.s})` }}
          >
            {t.text}
          </div>
        );
      })}
    </div>
  );
}

export function Overlay({ title, onClose, children, footer }: { title: string; onClose: () => void; children: ReactNode; footer?: ReactNode }) {
  return (
    <div className="fixed inset-0 z-[120] flex flex-col bg-[var(--bpa-bg)] anim-fade-in">
      <header className="bpa-safe-top sticky top-0 z-10 flex items-center gap-2 border-b border-[var(--bpa-line)] bg-[var(--bpa-panel)]/95 px-3 py-3 backdrop-blur">
        <IconButton onClick={onClose} aria-label="Đóng">
          <Icon name="back" size={22} />
        </IconButton>
        <h2 className="font-display flex-1 truncate text-base font-bold text-[var(--bpa-ink)]">{title}</h2>
      </header>
      <div className="bpa-no-scrollbar flex-1 overflow-y-auto px-4 py-4">{children}</div>
      {footer && <div className="bpa-safe-bottom border-t border-[var(--bpa-line)] bg-[var(--bpa-panel)] px-4 py-3">{footer}</div>}
    </div>
  );
}

export function Sheet({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="fixed inset-0 z-[130] flex flex-col justify-end bg-black/40 anim-fade-in" onClick={onClose}>
      <div
        className="anim-sheet bpa-safe-bottom max-h-[88dvh] overflow-y-auto rounded-t-3xl border-t border-[var(--bpa-line)] bg-[var(--bpa-panel)] px-4 pb-5 pt-3 bpa-no-scrollbar"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mb-3 h-1.5 w-10 rounded-full bg-[var(--bpa-line)]" />
        <div className="mb-3 flex items-center justify-between">
          <h3 className="font-display text-base font-bold text-[var(--bpa-ink)]">{title}</h3>
          <IconButton onClick={onClose} aria-label="Đóng">
            <Icon name="close" size={20} />
          </IconButton>
        </div>
        {children}
      </div>
    </div>
  );
}

export function ConfirmButton({ label = "Xóa", onConfirm, className }: { label?: string; onConfirm: () => void; className?: string }) {
  const [armed, setArmed] = useState(false);
  return (
    <button
      className={cx(
        "bpa-press inline-flex items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-[13px] font-semibold",
        armed
          ? "bg-[var(--bpa-error)] text-white"
          : "bg-[var(--bpa-error-soft)] text-[var(--bpa-error)]",
        className,
      )}
      onClick={() => (armed ? onConfirm() : setArmed(true))}
      onBlur={() => setArmed(false)}
    >
      <Icon name="trash" size={15} />
      {armed ? "Xác nhận?" : label}
    </button>
  );
}

export function HealthDot({ health }: { health: HealthId }) {
  const m = HEALTH_META[health];
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold"
      style={{ color: `var(${m.varName})`, backgroundColor: `var(${m.softVar})` }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: `var(${m.varName})` }} />
      {m.label}
    </span>
  );
}

export function LeafArt({ hue, size = 56, health }: { hue: number; size?: number; health?: HealthId }) {
  const a = `oklch(0.68 0.14 ${hue})`;
  const b = `oklch(0.5 0.12 ${(hue + 40) % 360})`;
  const ring = health ? `var(${HEALTH_META[health].varName})` : "transparent";
  return (
    <span
      className="relative inline-flex items-center justify-center rounded-2xl text-white"
      style={{ width: size, height: size, backgroundImage: `linear-gradient(140deg, ${a}, ${b})`, boxShadow: health ? `inset 0 0 0 2px ${ring}` : undefined }}
    >
      <Icon name="tree" size={Math.round(size * 0.5)} />
    </span>
  );
}

export function StatTile({
  icon,
  label,
  value,
  sub,
  tone = "green",
  onClick,
}: {
  icon: Parameters<typeof Icon>[0]["name"];
  label: string;
  value: ReactNode;
  sub?: string;
  tone?: "green" | "lime" | "water" | "warn";
  onClick?: () => void;
}) {
  const map = {
    green: { v: "--bpa-green-deep", s: "--bpa-green-soft" },
    lime: { v: "--bpa-lime-deep", s: "--bpa-lime-soft" },
    water: { v: "--bpa-water", s: "--bpa-water-soft" },
    warn: { v: "--bpa-warn", s: "--bpa-warn-soft" },
  }[tone];
  return (
    <button
      onClick={onClick}
      disabled={!onClick}
      className={cx(
        "flex flex-col items-start gap-2 rounded-2xl border border-[var(--bpa-line)] bg-[var(--bpa-panel)] p-3.5 text-left",
        onClick && "bpa-press",
      )}
    >
      <span className="flex h-9 w-9 items-center justify-center rounded-xl" style={{ color: `var(${map.v})`, backgroundColor: `var(${map.s})` }}>
        <Icon name={icon} size={18} />
      </span>
      <div>
        <p className="bpa-nums font-display text-2xl font-extrabold leading-none text-[var(--bpa-ink)]">{value}</p>
        <p className="mt-1 text-[12px] font-medium text-[var(--bpa-muted)]">{label}</p>
        {sub && <p className="text-[11px] text-[var(--bpa-faint)]">{sub}</p>}
      </div>
    </button>
  );
}
