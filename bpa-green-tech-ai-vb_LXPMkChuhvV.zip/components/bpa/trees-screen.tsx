"use client";

import { useMemo, useState } from "react";
import { Button, Card, Field, Icon, IconButton, Pill, Select, TextInput, cx } from "./ui";
import { ConfirmButton, HealthDot, LeafArt, Overlay, Sheet, EmptyStateWrap } from "./shared";
import { useBpa, type TreeInput } from "@/contexts/bpa-context";
import {
  CARE_META,
  HEALTH_META,
  HEALTH_ORDER,
  dateLabel,
  fold,
  relativeTime,
  todayIso,
  type HealthId,
  type Tree,
} from "@/lib/bpa/data";

export function TreesScreen() {
  const { trees, projects, projectName, addTree, updateTree, deleteTree, logs } = useBpa();
  const [query, setQuery] = useState("");
  const [health, setHealth] = useState<HealthId | "all">("all");
  const [openId, setOpenId] = useState<string | null>(null);
  const [editor, setEditor] = useState<{ mode: "new" } | { mode: "edit"; tree: Tree } | null>(null);

  const filtered = useMemo(() => {
    const q = fold(query.trim());
    return trees.filter((t) => {
      if (health !== "all" && t.health !== health) return false;
      if (!q) return true;
      return [t.name, t.code, t.species, t.location].some((v) => fold(v).includes(q));
    });
  }, [trees, query, health]);

  const openTree = openId ? trees.find((t) => t.id === openId) : null;

  return (
    <div className="mx-auto max-w-xl px-4 pb-28 pt-4">
      <ScreenHeader title="Quản lý cây xanh" subtitle={`${trees.length} cây trong hệ thống`} onAdd={() => setEditor({ mode: "new" })} />

      <div className="sticky top-0 z-10 -mx-4 mb-3 bg-[var(--bpa-bg)]/95 px-4 py-2 backdrop-blur">
        <div className="relative">
          <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[var(--bpa-faint)]">
            <Icon name="search" size={18} />
          </span>
          <TextInput
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Tìm mã cây, tên, chủng loại, vị trí…"
            className="pl-10"
          />
        </div>
        <div className="bpa-no-scrollbar mt-2 flex gap-2 overflow-x-auto">
          <Chip active={health === "all"} onClick={() => setHealth("all")}>
            Tất cả
          </Chip>
          {HEALTH_ORDER.map((h) => (
            <Chip key={h} active={health === h} onClick={() => setHealth(h)} varName={HEALTH_META[h].varName}>
              {HEALTH_META[h].label}
            </Chip>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <EmptyStateWrap
          icon="tree"
          title="Chưa có cây phù hợp"
          hint="Thêm cây mới hoặc điều chỉnh bộ lọc."
          action={<Button onClick={() => setEditor({ mode: "new" })}><Icon name="plus" size={16} />Thêm cây</Button>}
        />
      ) : (
        <div className="flex flex-col gap-2.5">
          {filtered.map((t) => (
            <button key={t.id} onClick={() => setOpenId(t.id)} className="bpa-press text-left">
              <Card className="flex items-center gap-3 p-3">
                <LeafArt hue={t.hue} health={t.health} size={52} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="bpa-nums rounded-md bg-[var(--bpa-panel-2)] px-1.5 py-0.5 text-[11px] font-bold text-[var(--bpa-muted)]">{t.code}</span>
                    <HealthDot health={t.health} />
                  </div>
                  <p className="mt-1 truncate text-[15px] font-bold text-[var(--bpa-ink)]">{t.name}</p>
                  <p className="truncate text-[12px] text-[var(--bpa-muted)]">
                    {t.species || "—"} · <span className="inline-flex items-center gap-0.5"><Icon name="pin" size={11} />{t.location || "Chưa rõ vị trí"}</span>
                  </p>
                </div>
                <Icon name="chevron" size={18} />
              </Card>
            </button>
          ))}
        </div>
      )}

      {openTree && (
        <TreeDetail
          tree={openTree}
          projectLabel={projectName(openTree.projectId)}
          logs={logs.filter((l) => l.linkType === "tree" && l.linkId === openTree.id)}
          onClose={() => setOpenId(null)}
          onEdit={() => {
            setEditor({ mode: "edit", tree: openTree });
            setOpenId(null);
          }}
          onDelete={() => {
            deleteTree(openTree.id);
            setOpenId(null);
          }}
        />
      )}

      {editor && (
        <TreeEditor
          initial={editor.mode === "edit" ? editor.tree : null}
          projects={projects}
          onClose={() => setEditor(null)}
          onSave={(input) => {
            if (editor.mode === "edit") updateTree(editor.tree.id, input);
            else addTree(input);
            setEditor(null);
          }}
        />
      )}
    </div>
  );
}

export function ScreenHeader({ title, subtitle, onAdd, addLabel = "Thêm" }: { title: string; subtitle?: string; onAdd?: () => void; addLabel?: string }) {
  return (
    <div className="mb-3 flex items-center justify-between">
      <div>
        <h1 className="font-display text-xl font-extrabold text-[var(--bpa-ink)]">{title}</h1>
        {subtitle && <p className="text-[12px] text-[var(--bpa-muted)]">{subtitle}</p>}
      </div>
      {onAdd && (
        <Button onClick={onAdd} className="!px-3">
          <Icon name="plus" size={16} />
          {addLabel}
        </Button>
      )}
    </div>
  );
}

function Chip({ active, onClick, children, varName }: { active: boolean; onClick: () => void; children: React.ReactNode; varName?: string }) {
  return (
    <button
      onClick={onClick}
      className={cx(
        "bpa-press flex-none rounded-full border px-3 py-1.5 text-[12px] font-semibold",
        active ? "border-transparent bpa-hero-grad text-[var(--bpa-on)]" : "border-[var(--bpa-line)] bg-[var(--bpa-panel)] text-[var(--bpa-muted)]",
      )}
      style={active && varName ? undefined : undefined}
    >
      {children}
    </button>
  );
}

function TreeDetail({
  tree,
  projectLabel,
  logs,
  onClose,
  onEdit,
  onDelete,
}: {
  tree: Tree;
  projectLabel: string;
  logs: ReturnType<typeof useBpa>["logs"];
  onClose: () => void;
  onEdit: () => void;
  onDelete: () => void;
}) {
  return (
    <Overlay
      title={tree.name}
      onClose={onClose}
      footer={
        <div className="flex items-center gap-2">
          <Button variant="outline" block onClick={onEdit}>
            <Icon name="edit" size={16} />
            Chỉnh sửa
          </Button>
          <ConfirmButton onConfirm={onDelete} />
        </div>
      }
    >
      <div className="flex items-center gap-3">
        <LeafArt hue={tree.hue} health={tree.health} size={72} />
        <div>
          <span className="bpa-nums rounded-md bg-[var(--bpa-panel-2)] px-2 py-0.5 text-[12px] font-bold text-[var(--bpa-muted)]">{tree.code}</span>
          <p className="mt-1 font-display text-lg font-extrabold text-[var(--bpa-ink)]">{tree.name}</p>
          <HealthDot health={tree.health} />
        </div>
      </div>

      <Card className="mt-4 divide-y divide-[var(--bpa-line-soft)]">
        <DetailRow icon="leaf" label="Chủng loại" value={tree.species || "—"} />
        <DetailRow icon="pin" label="Vị trí" value={tree.location || "—"} />
        <DetailRow icon="calendar" label="Ngày trồng" value={dateLabel(tree.plantedDate)} />
        <DetailRow icon="project" label="Dự án" value={projectLabel} />
      </Card>

      <h3 className="mb-2 mt-5 font-display text-base font-bold text-[var(--bpa-ink)]">Lịch sử chăm sóc</h3>
      {logs.length === 0 ? (
        <p className="rounded-xl border border-dashed border-[var(--bpa-line)] p-4 text-center text-sm text-[var(--bpa-muted)]">
          Chưa có hoạt động chăm sóc nào cho cây này.
        </p>
      ) : (
        <div className="flex flex-col gap-2">
          {logs.map((l) => (
            <Card key={l.id} className="flex items-start gap-3 p-3">
              <span className="flex h-8 w-8 flex-none items-center justify-center rounded-lg bg-[var(--bpa-green-soft)] text-[var(--bpa-green-deep)]">
                <Icon name={CARE_META[l.type].icon as Parameters<typeof Icon>[0]["name"]} size={16} />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-[13px] font-bold text-[var(--bpa-ink)]">{CARE_META[l.type].label}</p>
                {l.note && <p className="bpa-pre text-[12px] text-[var(--bpa-muted)]">{l.note}</p>}
                <p className="mt-0.5 text-[11px] text-[var(--bpa-faint)]">
                  {l.person || "Không rõ"} · {relativeTime(l.at)}
                </p>
              </div>
            </Card>
          ))}
        </div>
      )}
    </Overlay>
  );
}

export function DetailRow({ icon, label, value }: { icon: Parameters<typeof Icon>[0]["name"]; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3 px-3.5 py-3">
      <span className="flex h-8 w-8 flex-none items-center justify-center rounded-lg bg-[var(--bpa-panel-2)] text-[var(--bpa-muted)]">
        <Icon name={icon} size={16} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-[11px] text-[var(--bpa-faint)]">{label}</p>
        <p className="truncate text-[13px] font-semibold text-[var(--bpa-ink)]">{value}</p>
      </div>
    </div>
  );
}

function TreeEditor({
  initial,
  projects,
  onClose,
  onSave,
}: {
  initial: Tree | null;
  projects: ReturnType<typeof useBpa>["projects"];
  onClose: () => void;
  onSave: (input: TreeInput) => void;
}) {
  const [code, setCode] = useState(initial?.code ?? "");
  const [name, setName] = useState(initial?.name ?? "");
  const [species, setSpecies] = useState(initial?.species ?? "");
  const [plantedDate, setPlantedDate] = useState(initial?.plantedDate || todayIso());
  const [location, setLocation] = useState(initial?.location ?? "");
  const [health, setHealth] = useState<HealthId>(initial?.health ?? "khoe");
  const [projectId, setProjectId] = useState<string>(initial?.projectId ?? "");

  const valid = name.trim().length > 0;

  return (
    <Sheet title={initial ? "Chỉnh sửa cây" : "Thêm cây mới"} onClose={onClose}>
      <div className="flex flex-col gap-3">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Mã cây">
            <TextInput value={code} onChange={(e) => setCode(e.target.value)} placeholder="C-0001" />
          </Field>
          <Field label="Tình trạng">
            <Select value={health} onChange={(e) => setHealth(e.target.value as HealthId)}>
              {HEALTH_ORDER.map((h) => (
                <option key={h} value={h}>{HEALTH_META[h].label}</option>
              ))}
            </Select>
          </Field>
        </div>
        <Field label="Tên cây">
          <TextInput value={name} onChange={(e) => setName(e.target.value)} placeholder="Ví dụ: Bằng Lăng" />
        </Field>
        <Field label="Chủng loại">
          <TextInput value={species} onChange={(e) => setSpecies(e.target.value)} placeholder="Tên khoa học / nhóm cây" />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Ngày trồng">
            <TextInput type="date" value={plantedDate} onChange={(e) => setPlantedDate(e.target.value)} />
          </Field>
          <Field label="Dự án">
            <Select value={projectId} onChange={(e) => setProjectId(e.target.value)}>
              <option value="">Không thuộc dự án</option>
              {projects.map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </Select>
          </Field>
        </div>
        <Field label="Vị trí">
          <TextInput value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Khu vực / tọa độ mô tả" />
        </Field>
        <Button
          block
          disabled={!valid}
          onClick={() => onSave({ code, name, species, plantedDate, location, health, projectId: projectId || null })}
        >
          <Icon name="check" size={16} />
          {initial ? "Lưu thay đổi" : "Thêm cây"}
        </Button>
      </div>
    </Sheet>
  );
}
