"use client";

import type { ReactNode } from "react";
import { EmptyState, type Icon } from "./ui";

export { ConfirmButton, HealthDot, LeafArt, Overlay, Sheet, StatTile } from "./pieces";

export function EmptyStateWrap({
  icon = "leaf",
  title,
  hint,
  action,
}: {
  icon?: Parameters<typeof Icon>[0]["name"];
  title: string;
  hint?: string;
  action?: ReactNode;
}) {
  return <EmptyState icon={icon} title={title} hint={hint} action={action} />;
}
