"use client";

import { useEffect, useMemo, useRef, useState, type KeyboardEvent } from "react";
import { Button, Card, Icon, IconButton, cx } from "./ui";
import { Sheet } from "./shared";
import { useBpa } from "@/contexts/bpa-context";
import { HEALTH_META, KNOWLEDGE, SUGGESTED_PROMPTS, type ChatMsg } from "@/lib/bpa/data";

export function AssistantScreen() {
  const { chat, pushChat, clearChat, trees, projects, zones, healthPct, activeZoneCount, priorityTasks } = useBpa();
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [knowledgeOpen, setKnowledgeOpen] = useState(false);
  const [tasksOpen, setTasksOpen] = useState(false);
  const scrollerRef = useRef<HTMLDivElement>(null);

  const contextSummary = useMemo(() => {
    const needWatch = trees.filter((t) => t.health === "theo_doi" || t.health === "yeu" || t.health === "benh");
    const dry = zones.filter((z) => z.moisture < 40);
    return [
      `Tổng số cây: ${trees.length}, tỷ lệ cây khỏe: ${healthPct}%.`,
      `Cây cần chú ý: ${needWatch.slice(0, 8).map((t) => `${t.name}(${HEALTH_META[t.health].label})`).join(", ") || "không"}.`,
      `Dự án: ${projects.map((p) => `${p.name} ${p.progress}%`).join("; ") || "chưa có"}.`,
      `Khu tưới đang hoạt động: ${activeZoneCount}/${zones.length}. Khu vực độ ẩm thấp: ${dry.map((z) => `${z.name} ${Math.round(z.moisture)}%`).join(", ") || "không"}.`,
    ].join("\n");
  }, [trees, projects, zones, healthPct, activeZoneCount]);

  useEffect(() => {
    scrollerRef.current?.scrollTo({ top: scrollerRef.current.scrollHeight, behavior: "smooth" });
  }, [chat, busy]);

  async function send(text: string) {
    const q = text.trim();
    if (!q || busy) return;
    setInput("");
    const userMsg: ChatMsg = { role: "user", text: q, at: Date.now() };
    pushChat(userMsg);
    setBusy(true);
    const history = [...chat, userMsg].map((m) => ({ role: m.role, content: m.text }));
    try {
      const res = await fetch("/api/green-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: history, context: contextSummary }),
      });
      const data = await res.json();
      if (!res.ok || !data.text) {
        pushChat({ role: "assistant", text: data.error || "Xin lỗi, trợ lý gặp sự cố. Vui lòng thử lại.", at: Date.now() });
      } else {
        pushChat({ role: "assistant", text: data.text, at: Date.now() });
      }
    } catch {
      pushChat({ role: "assistant", text: "Không có kết nối mạng. Vui lòng kiểm tra và thử lại.", at: Date.now() });
    } finally {
      setBusy(false);
    }
  }

  function onKey(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing && e.keyCode !== 229) {
      e.preventDefault();
      send(input);
    }
  }

  return (
    <div className="mx-auto flex h-[calc(100dvh-4.5rem)] max-w-xl flex-col">
      <header className="flex items-center gap-2 border-b border-[var(--bpa-line)] px-4 py-3">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bpa-hero-grad text-[var(--bpa-on)]">
          <Icon name="robot" size={20} />
        </span>
        <div className="flex-1">
          <p className="font-display text-[15px] font-extrabold text-[var(--bpa-ink)]">BPA.Green AI</p>
          <p className="text-[11px] text-[var(--bpa-muted)]">Kỹ sư nông nghiệp số · Blockchain &amp; Web3</p>
        </div>
        <IconButton onClick={() => setTasksOpen(true)} aria-label="Công việc ưu tiên">
          <Icon name="chart" size={20} />
        </IconButton>
        <IconButton onClick={() => setKnowledgeOpen(true)} aria-label="Thư viện kiến thức">
          <Icon name="book" size={20} />
        </IconButton>
        {chat.length > 0 && (
          <IconButton onClick={clearChat} aria-label="Xóa hội thoại">
            <Icon name="trash" size={18} />
          </IconButton>
        )}
      </header>

      <div ref={scrollerRef} className="bpa-no-scrollbar flex-1 overflow-y-auto px-4 py-4">
        {chat.length === 0 ? (
          <div className="anim-fade-up">
            <div className="rounded-2xl bpa-lime-grad p-4 text-[var(--bpa-green-deep)]">
              <p className="font-display text-[15px] font-extrabold">Xin chào! Tôi là BPA.Green AI.</p>
              <p className="mt-1 text-[13px]">Tôi hỗ trợ kiến thức cây trồng, quy trình chăm sóc, tưới, IoT, quản lý công trình, blockchain và Web3.</p>
            </div>
            <p className="mb-2 mt-5 text-[12px] font-semibold uppercase tracking-wide text-[var(--bpa-faint)]">Gợi ý câu hỏi</p>
            <div className="flex flex-col gap-2">
              {SUGGESTED_PROMPTS.map((p) => (
                <button
                  key={p}
                  onClick={() => send(p)}
                  className="bpa-press flex items-center gap-2.5 rounded-xl border border-[var(--bpa-line)] bg-[var(--bpa-panel)] px-3.5 py-3 text-left text-[13px] font-medium text-[var(--bpa-ink)]"
                >
                  <span className="text-[var(--bpa-green)]"><Icon name="sparkle" size={16} /></span>
                  {p}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {chat.map((m, i) => (
              <div key={i} className={cx("flex", m.role === "user" ? "justify-end" : "justify-start")}>
                <div
                  className={cx(
                    "max-w-[85%] rounded-2xl px-3.5 py-2.5 text-[13.5px] leading-relaxed",
                    m.role === "user"
                      ? "bpa-hero-grad text-[var(--bpa-on)] rounded-br-md"
                      : "border border-[var(--bpa-line)] bg-[var(--bpa-panel)] text-[var(--bpa-ink)] rounded-bl-md",
                  )}
                >
                  <p className="bpa-pre">{m.text}</p>
                </div>
              </div>
            ))}
            {busy && (
              <div className="flex justify-start">
                <div className="flex items-center gap-1.5 rounded-2xl rounded-bl-md border border-[var(--bpa-line)] bg-[var(--bpa-panel)] px-4 py-3">
                  <Dot /><Dot d={0.15} /><Dot d={0.3} />
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="bpa-safe-bottom border-t border-[var(--bpa-line)] bg-[var(--bpa-panel)] px-3 py-3">
        <div className="flex items-end gap-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={onKey}
            rows={1}
            placeholder="Hỏi trợ lý về cây xanh, tưới, sâu bệnh…"
            className="max-h-28 flex-1 resize-none rounded-2xl border border-[var(--bpa-line)] bg-[var(--bpa-bg)] px-3.5 py-2.5 text-sm text-[var(--bpa-ink)] outline-none placeholder:text-[var(--bpa-faint)] focus:border-[var(--bpa-green)]"
          />
          <button
            onClick={() => send(input)}
            disabled={!input.trim() || busy}
            className="bpa-press flex h-11 w-11 flex-none items-center justify-center rounded-2xl bpa-hero-grad text-[var(--bpa-on)] disabled:opacity-40"
            aria-label="Gửi"
          >
            <Icon name="send" size={18} />
          </button>
        </div>
      </div>

      {knowledgeOpen && (
        <Sheet title="Thư viện kiến thức" onClose={() => setKnowledgeOpen(false)}>
          <div className="flex flex-col gap-3">
            {KNOWLEDGE.map((k) => (
              <Card key={k.title} className="p-3.5">
                <div className="flex items-center gap-2">
                  <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[var(--bpa-green-soft)] text-[var(--bpa-green-deep)]">
                    <Icon name={k.icon as Parameters<typeof Icon>[0]["name"]} size={16} />
                  </span>
                  <p className="font-display text-[14px] font-bold text-[var(--bpa-ink)]">{k.title}</p>
                </div>
                <p className="mt-2 text-[13px] leading-relaxed text-[var(--bpa-muted)]">{k.body}</p>
                <button
                  onClick={() => { setKnowledgeOpen(false); send(k.ask); }}
                  className="bpa-press mt-2 inline-flex items-center gap-1 text-[12px] font-semibold text-[var(--bpa-green-deep)]"
                >
                  Hỏi trợ lý về chủ đề này <Icon name="arrow" size={14} />
                </button>
              </Card>
            ))}
          </div>
        </Sheet>
      )}

      {tasksOpen && (
        <Sheet title="Công việc ưu tiên" onClose={() => setTasksOpen(false)}>
          <p className="mb-3 text-[13px] text-[var(--bpa-muted)]">Danh sách được đề xuất dựa trên tình trạng cây, độ ẩm khu tưới và tiến độ dự án.</p>
          {priorityTasks.length === 0 ? (
            <Card className="flex items-center gap-3 p-4">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[var(--bpa-khoe-soft)] text-[var(--bpa-khoe)]"><Icon name="check" size={18} /></span>
              <p className="text-[13px] text-[var(--bpa-muted)]">Không có công việc gấp. Hệ thống đang ổn định.</p>
            </Card>
          ) : (
            <div className="flex flex-col gap-2">
              {priorityTasks.map((t, i) => (
                <Card key={i} className="flex items-start gap-3 p-3.5">
                  <span
                    className="mt-0.5 flex h-7 w-7 flex-none items-center justify-center rounded-full text-[12px] font-bold"
                    style={{ color: `var(${t.tone})`, backgroundColor: `var(${t.tone}-soft)` }}
                  >
                    {i + 1}
                  </span>
                  <p className="text-[13px] font-medium text-[var(--bpa-ink)]">{t.text}</p>
                </Card>
              ))}
            </div>
          )}
          <Button
            block
            className="mt-4"
            onClick={() => { setTasksOpen(false); send("Dựa trên dữ liệu hệ thống, hãy lập kế hoạch chăm sóc ưu tiên cho tuần này và giải thích lý do."); }}
          >
            <Icon name="sparkle" size={16} />
            Nhờ trợ lý lập kế hoạch chi tiết
          </Button>
        </Sheet>
      )}
    </div>
  );
}

function Dot({ d = 0 }: { d?: number }) {
  return <span className="h-2 w-2 animate-bounce rounded-full bg-[var(--bpa-green)]" style={{ animationDelay: `${d}s` }} />;
}
