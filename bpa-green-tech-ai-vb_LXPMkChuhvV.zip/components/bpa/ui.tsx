"use client";

import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SVGProps, TextareaHTMLAttributes, SelectHTMLAttributes } from "react";

export function cx(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

type IconName =
  | "leaf" | "tree" | "project" | "droplet" | "log" | "clipboard" | "robot"
  | "bell" | "search" | "plus" | "close" | "back" | "chevron" | "chevronDown"
  | "edit" | "trash" | "check" | "calendar" | "pin" | "user" | "play" | "pause"
  | "warn" | "send" | "filter" | "arrow" | "sparkle" | "fertilizer" | "scissors"
  | "bug" | "refresh" | "home" | "book" | "chart" | "pen" | "sun" | "grid" | "info"
  | "users" | "cpu" | "building" | "shield" | "report" | "more" | "cloud" | "camera";

const PATHS: Record<IconName, ReactNode> = {
  leaf: <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Zm0 0c0-4.7 1.35-7.85 4-11" />,
  tree: <><path d="M12 22v-6" /><path d="M9 16a5 5 0 0 1-2-9.6A4 4 0 0 1 12 3a4 4 0 0 1 5 3.4A5 5 0 0 1 15 16Z" /></>,
  project: <><path d="M3 21h18" /><path d="M5 21V7l7-4 7 4v14" /><path d="M9 21v-4h6v4" /><path d="M9 10h.01M15 10h.01M9 13h.01M15 13h.01" /></>,
  droplet: <path d="M12 2.7 6.3 9.4a7.5 7.5 0 1 0 11.4 0Z" />,
  log: <><path d="M4 4h13a2 2 0 0 1 2 2v14l-3-2-3 2-3-2-3 2V6a2 2 0 0 1 2-2Z" /><path d="M8 8h7M8 12h7" /></>,
  clipboard: <><rect x="8" y="3" width="8" height="4" rx="1" /><path d="M8 5H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2" /><path d="m9 14 2 2 4-4" /></>,
  robot: <><rect x="5" y="8" width="14" height="11" rx="2" /><path d="M12 8V4M9 3h6" /><circle cx="9" cy="13" r="1" /><circle cx="15" cy="13" r="1" /><path d="M2 12v3M22 12v3" /></>,
  bell: <><path d="M6 9a6 6 0 0 1 12 0c0 5 2 6 2 6H4s2-1 2-6" /><path d="M10.5 20a1.8 1.8 0 0 0 3 0" /></>,
  search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-3.2-3.2" /></>,
  plus: <path d="M12 5v14M5 12h14" />,
  close: <path d="M6 6l12 12M18 6 6 18" />,
  back: <path d="M15 18l-6-6 6-6" />,
  chevron: <path d="M9 6l6 6-6 6" />,
  chevronDown: <path d="M6 9l6 6 6-6" />,
  edit: <><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z" /></>,
  trash: <><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13" /></>,
  check: <path d="M5 12l5 5L20 6" />,
  calendar: <><rect x="3" y="4" width="18" height="17" rx="2" /><path d="M3 9h18M8 2v4M16 2v4" /></>,
  pin: <><path d="M12 21s-6-5.3-6-10a6 6 0 0 1 12 0c0 4.7-6 10-6 10Z" /><circle cx="12" cy="11" r="2" /></>,
  user: <><circle cx="12" cy="8" r="4" /><path d="M4 20a8 8 0 0 1 16 0" /></>,
  play: <path d="M7 5l12 7-12 7Z" />,
  pause: <><rect x="7" y="5" width="3.5" height="14" rx="1" /><rect x="13.5" y="5" width="3.5" height="14" rx="1" /></>,
  warn: <><path d="M12 3 2 20h20L12 3Z" /><path d="M12 9v5M12 17h.01" /></>,
  send: <path d="M4 12 20 4l-6 16-3-7-7-1Z" />,
  filter: <path d="M3 5h18l-7 8v6l-4-2v-4Z" />,
  arrow: <path d="M5 12h14M13 6l6 6-6 6" />,
  sparkle: <path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9Z" />,
  fertilizer: <><path d="M6 21V9l6-4 6 4v12" /><path d="M6 13h12M10 21v-5h4v5" /></>,
  scissors: <><circle cx="6" cy="6" r="2.5" /><circle cx="6" cy="18" r="2.5" /><path d="M8 8l12 8M8 16l12-8" /></>,
  bug: <><path d="M8 8a4 4 0 0 1 8 0v5a4 4 0 0 1-8 0Z" /><path d="M4 10h4M16 10h4M4 15h4M16 15h4M9 4l1.5 2M15 4l-1.5 2" /></>,
  refresh: <><path d="M20 11a8 8 0 1 0-.9 4.5" /><path d="M20 4v6h-6" /></>,
  home: <><path d="M3 11l9-8 9 8" /><path d="M5 9.5V21h14V9.5" /></>,
  book: <><path d="M4 4h13a2 2 0 0 1 2 2v14H6a2 2 0 0 0-2 2Z" /><path d="M4 4v16" /></>,
  chart: <><path d="M4 20V4" /><path d="M4 20h16" /><rect x="7" y="12" width="3" height="5" /><rect x="12" y="8" width="3" height="9" /><rect x="17" y="5" width="3" height="12" /></>,
  pen: <path d="M4 20l4-1L19 8a2.1 2.1 0 0 0-3-3L5 16Z" />,
  sun: <><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5 19 19M19 5l-1.5 1.5M6.5 17.5 5 19" /></>,
  grid: <><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /></>,
  info: <><circle cx="12" cy="12" r="9" /><path d="M12 11v5M12 8h.01" /></>,
  users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></>,
  cpu: <><rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v4M15 1v4M9 19v4M15 19v4M1 9h4M1 15h4M19 9h4M19 15h4"/></>,
  building: <><path d="M3 21h18M5 21V4h10v17M15 9h4v12"/><path d="M8 8h4M8 12h4M8 16h4"/></>,
  shield: <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/>,
  report: <><path d="M4 4h16v16H4z"/><path d="M8 9h8M8 13h8M8 17h5"/></>,
  more: <><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>,
  cloud: <path d="M17.5 19H7a5 5 0 1 1 1.5-9.8A6 6 0 0 1 20 11a4 4 0 0 1-2.5 8Z"/>,
  camera: <><path d="M14.5 4 16 7h4a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h4l1.5-3Z"/><circle cx="12" cy="13" r="3"/></>,
};

export function Icon({ name, size = 20, ...rest }: { name: IconName; size?: number } & SVGProps<SVGSVGElement>) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.9}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      {...rest}
    >
      {PATHS[name]}
    </svg>
  );
}

type ButtonVariant = "primary" | "lime" | "solid" | "outline" | "ghost" | "danger";
const BTN: Record<ButtonVariant, string> = {
  primary: "bpa-hero-grad text-[var(--bpa-on)] shadow-sm",
  lime: "bpa-lime-grad text-[var(--bpa-green-deep)] shadow-sm",
  solid: "bg-[var(--bpa-panel-2)] text-[var(--bpa-ink)] border border-[var(--bpa-line)]",
  outline: "bg-transparent text-[var(--bpa-green-deep)] border border-[var(--bpa-green)]",
  ghost: "bg-transparent text-[var(--bpa-muted)]",
  danger: "bg-[var(--bpa-error-soft)] text-[var(--bpa-error)] border border-[color-mix(in_oklab,var(--bpa-error)_30%,transparent)]",
};

export function Button({
  variant = "primary",
  block,
  className,
  children,
  ...rest
}: { variant?: ButtonVariant; block?: boolean } & ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      className={cx(
        "bpa-press inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold disabled:opacity-45 disabled:pointer-events-none",
        block && "w-full",
        BTN[variant],
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
}

export function IconButton({
  className,
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      className={cx(
        "bpa-press inline-flex h-10 w-10 items-center justify-center rounded-xl text-[var(--bpa-muted)] hover:text-[var(--bpa-ink)]",
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
}

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <div className={cx("rounded-2xl border border-[var(--bpa-line)] bg-[var(--bpa-panel)]", className)}>
      {children}
    </div>
  );
}

export function Eyebrow({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <p className={cx("text-[11px] font-semibold uppercase tracking-wide text-[var(--bpa-faint)]", className)}>
      {children}
    </p>
  );
}

export function SectionTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="mb-2.5 flex items-center justify-between">
      <h2 className="font-display text-base font-bold text-[var(--bpa-ink)]">{children}</h2>
      {action}
    </div>
  );
}

type PillTone = "green" | "lime" | "water" | "warn" | "error" | "neutral";
export function Pill({ tone = "neutral", children, className }: { tone?: PillTone; children: ReactNode; className?: string }) {
  const map: Record<PillTone, { v: string; s: string }> = {
    green: { v: "--bpa-khoe", s: "--bpa-khoe-soft" },
    lime: { v: "--bpa-lime-deep", s: "--bpa-lime-soft" },
    water: { v: "--bpa-water", s: "--bpa-water-soft" },
    warn: { v: "--bpa-warn", s: "--bpa-warn-soft" },
    error: { v: "--bpa-error", s: "--bpa-error-soft" },
    neutral: { v: "--bpa-muted", s: "--bpa-panel-2" },
  };
  const c = map[tone];
  return (
    <span
      className={cx("inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-semibold", className)}
      style={{ color: `var(${c.v})`, backgroundColor: `var(${c.s})` }}
    >
      {children}
    </span>
  );
}

export function StatusChip({ label, varName, softVar }: { label: string; varName: string; softVar: string }) {
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold"
      style={{ color: `var(${varName})`, backgroundColor: `var(${softVar})` }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: `var(${varName})` }} />
      {label}
    </span>
  );
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[13px] font-semibold text-[var(--bpa-ink)]">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-[11px] text-[var(--bpa-faint)]">{hint}</span>}
    </label>
  );
}

export const inputClass =
  "w-full rounded-xl border border-[var(--bpa-line)] bg-[var(--bpa-panel)] px-3.5 py-2.5 text-sm text-[var(--bpa-ink)] outline-none placeholder:text-[var(--bpa-faint)] focus:border-[var(--bpa-green)]";

export function TextInput(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input className={cx(inputClass, props.className)} {...props} />;
}

export function TextArea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className={cx(inputClass, "resize-none", props.className)} {...props} />;
}

export function Select({ children, className, ...rest }: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <div className="relative">
      <select
        className={cx(inputClass, "appearance-none pr-9", className)}
        {...rest}
      >
        {children}
      </select>
      <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[var(--bpa-faint)]">
        <Icon name="chevronDown" size={16} />
      </span>
    </div>
  );
}

export function Spinner({ size = 22 }: { size?: number }) {
  return (
    <span
      className="anim-spin inline-block rounded-full border-2 border-[var(--bpa-line)]"
      style={{ width: size, height: size, borderTopColor: "var(--bpa-green)" }}
    />
  );
}

export function ProgressBar({ value, tone = "green" }: { value: number; tone?: "green" | "lime" | "water" }) {
  const color = tone === "water" ? "--bpa-water" : tone === "lime" ? "--bpa-lime-deep" : "--bpa-green";
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-[var(--bpa-panel-2)]">
      <div
        className="h-full rounded-full transition-all"
        style={{ width: `${Math.max(0, Math.min(100, value))}%`, backgroundColor: `var(${color})` }}
      />
    </div>
  );
}

export function EmptyState({ icon = "leaf", title, hint, action }: { icon?: IconName; title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-[var(--bpa-line)] bg-[var(--bpa-panel)] px-6 py-12 text-center">
      <span className="mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-[var(--bpa-green-soft)] text-[var(--bpa-green-deep)]">
        <Icon name={icon} size={26} />
      </span>
      <p className="font-display text-base font-bold text-[var(--bpa-ink)]">{title}</p>
      {hint && <p className="mt-1 max-w-xs text-sm text-[var(--bpa-muted)]">{hint}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
