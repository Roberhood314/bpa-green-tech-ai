"use client";

import { useMemo, useState } from "react";
import { Button, Card, Field, Icon, Pill, Select, TextArea, TextInput, cx } from "./ui";
import { ConfirmButton, Sheet, EmptyStateWrap } from "./shared";
import { ScreenHeader } from "./trees-screen";
import { useBpa, type LogInput } from "@/contexts/bpa-context";
import { CARE_META, CARE_ORDER, relativeTime, type CareLog, type CareType } from "@/lib/bpa/data";

export function CareLogScreen() {
  const { logs, trees, zones, projects, getTree, getProject, addLog, deleteLog } = useBpa();
  const [filter, setFilter] = useState<CareType | "all">("all");
  const [adding, setAdding] = useState(false);

  const filtered = useMemo(() => (filter === "all" ? logs : logs.filter((l) => l.type === filter)), [logs, filter]);

  function linkLabel(l: CareLog): string | null {
    if (l.linkType === "tree") return getTree(l.linkId)?.name ? `Cây: ${getTree(l.linkId)!.name}` : null;
    if (l.linkType === "project") return getProject(l.linkId)?.name ? `Dự án: ${getProject(l.linkId)!.name}` : null;
    if (l.linkType === "zone") return zones.find((z) => z.id === l.linkId)?.name ? `Khu tưới: ${zones.find((z) => z.id === l.linkId)!.name}` : null;
    return null;
  }

  return (
    <div className="mx-auto max-w-xl px-4 pb-28 pt-4">
      <ScreenHeader title="Nhật ký chăm sóc" subtitle={`${logs.length} hoạt động đã ghi nhận`} onAdd={() => setAdding(true)} addLabel="Ghi" />

      <div className="bpa-no-scrollbar mb-3 flex gap-2 overflow-x-auto">
        <FilterChip active={filter === "all"} onClick={() => setFilter("all")}>Tất cả</FilterChip>
        {CARE_ORDER.map((c) => (
          <FilterChip key={c} active={filter === c} onClick={() => setFilter(c)}>
            {CARE_META[c].label}
          </FilterChip>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyStateWrap icon="log" title="Chưa có nhật ký" hint="Ghi lại các hoạt động chăm sóc cây xanh hằng ngày." action={<Button onClick={() => setAdding(true)}><Icon name="plus" size={16} />Ghi nhật ký</Button>} />
      ) : (
        <div className="relative flex flex-col gap-3 pl-5">
          <span className="absolute left-[7px] top-2 bottom-2 w-px bg-[var(--bpa-line)]" />
          {filtered.map((l) => {
            const link = linkLabel(l);
            return (
              <div key={l.id} className="relative">
                <span className="absolute -left-5 top-3 flex h-4 w-4 items-center justify-center rounded-full bg-[var(--bpa-green)] ring-4 ring-[var(--bpa-bg)]" />
                <Card className="p-3.5">
                  <div className="flex items-start gap-3">
                    <span className="flex h-9 w-9 flex-none items-center justify-center rounded-xl bg-[var(--bpa-green-soft)] text-[var(--bpa-green-deep)]">
                      <Icon name={CARE_META[l.type].icon as Parameters<typeof Icon>[0]["name"]} size={18} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-[14px] font-bold text-[var(--bpa-ink)]">{CARE_META[l.type].label}</p>
                        <ConfirmButton label="" onConfirm={() => deleteLog(l.id)} className="!px-2 !py-1" />
                      </div>
                      {l.note && <p className="bpa-pre mt-0.5 text-[13px] text-[var(--bpa-muted)]">{l.note}</p>}
                      {link && (
                        <span className="mt-1.5 inline-block">
                          <Pill tone="lime">{link}</Pill>
                        </span>
                      )}
                      <p className="mt-1.5 flex items-center gap-1.5 text-[11px] text-[var(--bpa-faint)]">
                        <Icon name="user" size={12} />
                        {l.person || "Không rõ"} · {relativeTime(l.at)}
                      </p>
                    </div>
                  </div>
                </Card>
              </div>
            );
          })}
        </div>
      )}

      {adding && (
        <LogEditor
          trees={trees}
          zones={zones}
          projects={projects}
          onClose={() => setAdding(false)}
          onSave={(input) => {
            addLog(input);
            setAdding(false);
          }}
        />
      )}
    </div>
  );
}

function FilterChip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={cx(
        "bpa-press flex-none rounded-full border px-3 py-1.5 text-[12px] font-semibold",
        active ? "border-transparent bpa-hero-grad text-[var(--bpa-on)]" : "border-[var(--bpa-line)] bg-[var(--bpa-panel)] text-[var(--bpa-muted)]",
      )}
    >
      {children}
    </button>
  );
}

function LogEditor({
  trees,
  zones,
  projects,
  onClose,
  onSave,
}: {
  trees: ReturnType<typeof useBpa>["trees"];
  zones: ReturnType<typeof useBpa>["zones"];
  projects: ReturnType<typeof useBpa>["projects"];
  onClose: () => void;
  onSave: (input: LogInput) => void;
}) {
  const [type, setType] = useState<CareType>("tuoi");
  const [person, setPerson] = useState("");
  const [note, setNote] = useState("");
  const [linkType, setLinkType] = useState<LogInput["linkType"]>("none");
  const [linkId, setLinkId] = useState<string>("");

  const options = linkType === "tree" ? trees.map((t) => ({ id: t.id, label: `${t.name} (${t.code})` })) : linkType === "zone" ? zones.map((z) => ({ id: z.id, label: z.name })) : linkType === "project" ? projects.map((p) => ({ id: p.id, label: p.name })) : [];

  return (
    <Sheet title="Ghi nhật ký chăm sóc" onClose={onClose}>
      <div className="flex flex-col gap-3">
        <Field label="Loại hoạt động">
          <div className="grid grid-cols-2 gap-2">
            {CARE_ORDER.map((c) => (
              <button
                key={c}
                onClick={() => setType(c)}
                className={cx(
                  "bpa-press flex items-center gap-2 rounded-xl border px-3 py-2.5 text-[13px] font-semibold",
                  type === c ? "border-[var(--bpa-green)] bg-[var(--bpa-green-soft)] text-[var(--bpa-green-deep)]" : "border-[var(--bpa-line)] text-[var(--bpa-muted)]",
                )}
              >
                <Icon name={CARE_META[c].icon as Parameters<typeof Icon>[0]["name"]} size={16} />
                {CARE_META[c].label}
              </button>
            ))}
          </div>
        </Field>
        <Field label="Người thực hiện">
          <TextInput value={person} onChange={(e) => setPerson(e.target.value)} placeholder="Tên nhân viên" />
        </Field>
        <Field label="Ghi chú">
          <TextArea rows={3} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Mô tả hoạt động, tình trạng, vật tư sử dụng…" />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Liên kết với">
            <Select value={linkType} onChange={(e) => { setLinkType(e.target.value as LogInput["linkType"]); setLinkId(""); }}>
              <option value="none">Không</option>
              <option value="tree">Cây</option>
              <option value="zone">Khu tưới</option>
              <option value="project">Dự án</option>
            </Select>
          </Field>
          <Field label="Đối tượng">
            <Select value={linkId} onChange={(e) => setLinkId(e.target.value)} disabled={linkType === "none"}>
              <option value="">{linkType === "none" ? "—" : "Chọn"}</option>
              {options.map((o) => (
                <option key={o.id} value={o.id}>{o.label}</option>
              ))}
            </Select>
          </Field>
        </div>
        <Button block onClick={() => onSave({ type, person, note, linkType, linkId: linkType === "none" ? null : linkId || null })}>
          <Icon name="check" size={16} />
          Lưu nhật ký
        </Button>
      </div>
    </Sheet>
  );
}
