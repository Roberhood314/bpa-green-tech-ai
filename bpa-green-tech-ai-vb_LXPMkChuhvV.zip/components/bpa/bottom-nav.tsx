"use client";

import { cx, Icon } from "./ui";
import { useBpa } from "@/contexts/bpa-context";
import type { ModuleId } from "@/lib/bpa/data";

const TABS: Array<{ id: ModuleId; label: string; icon: Parameters<typeof Icon>[0]["name"] }> = [
  { id: "dashboard", label: "Tổng quan", icon: "home" },
  { id: "trees", label: "Cây xanh", icon: "tree" },
  { id: "personnel", label: "Nhân sự", icon: "users" },
  { id: "iot", label: "IoT", icon: "cpu" },
  { id: "more", label: "Thêm", icon: "more" },
];

export function BottomNav() {
  const { tab, setTab } = useBpa();
  return (
    <nav className="bpa-safe-bottom fixed inset-x-0 bottom-0 z-[80] border-t border-[var(--bpa-line)] bg-[var(--bpa-panel)]/95 backdrop-blur">
      <div className="mx-auto flex max-w-xl items-stretch justify-around px-1.5 py-1.5">
        {TABS.map((t) => {
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className="bpa-press flex flex-1 flex-col items-center gap-1 rounded-xl py-1.5"
            >
              <span
                className={cx(
                  "flex h-9 w-14 items-center justify-center rounded-full transition-colors",
                  active ? "bpa-hero-grad text-[var(--bpa-on)]" : "text-[var(--bpa-faint)]",
                )}
              >
                <Icon name={t.icon} size={20} />
              </span>
              <span className={cx("text-[10.5px] font-semibold", active ? "text-[var(--bpa-green-deep)]" : "text-[var(--bpa-faint)]")}>
                {t.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
