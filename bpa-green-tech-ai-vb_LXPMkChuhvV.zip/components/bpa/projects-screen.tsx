"use client";

import { useMemo, useState } from "react";
import { Button, Card, Field, Icon, Pill, ProgressBar, TextInput } from "./ui";
import { ConfirmButton, LeafArt, Overlay, Sheet, EmptyStateWrap } from "./shared";
import { ScreenHeader, DetailRow } from "./trees-screen";
import { useBpa, type ProjectInput } from "@/contexts/bpa-context";
import { CARE_META, dateLabel, relativeTime, todayIso, type Project } from "@/lib/bpa/data";

export function ProjectsScreen() {
  const { projects, trees, addProject, updateProject, deleteProject } = useBpa();
  const [openId, setOpenId] = useState<string | null>(null);
  const [editor, setEditor] = useState<{ mode: "new" } | { mode: "edit"; project: Project } | null>(null);

  const countFor = (id: string) => trees.filter((t) => t.projectId === id).length;
  const openProject = openId ? projects.find((p) => p.id === openId) : null;

  return (
    <div className="mx-auto max-w-xl px-4 pb-28 pt-4">
      <ScreenHeader title="Dự án / công trình" subtitle={`${projects.length} dự án cảnh quan`} onAdd={() => setEditor({ mode: "new" })} addLabel="Tạo" />

      {projects.length === 0 ? (
        <EmptyStateWrap icon="project" title="Chưa có dự án" hint="Tạo dự án đầu tiên để theo dõi tiến độ thi công." action={<Button onClick={() => setEditor({ mode: "new" })}><Icon name="plus" size={16} />Tạo dự án</Button>} />
      ) : (
        <div className="flex flex-col gap-3">
          {projects.map((p) => (
            <button key={p.id} onClick={() => setOpenId(p.id)} className="bpa-press text-left">
              <Card className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate font-display text-[15px] font-bold text-[var(--bpa-ink)]">{p.name}</p>
                    <p className="mt-0.5 flex items-center gap-1 truncate text-[12px] text-[var(--bpa-muted)]">
                      <Icon name="pin" size={12} />
                      {p.location || "—"}
                    </p>
                  </div>
                  <Pill tone={p.progress >= 100 ? "green" : "lime"}>{p.progress}%</Pill>
                </div>
                <div className="mt-3">
                  <ProgressBar value={p.progress} tone={p.progress >= 100 ? "green" : "lime"} />
                </div>
                <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-[12px] text-[var(--bpa-muted)]">
                  <span className="flex items-center gap-1"><Icon name="tree" size={13} />{countFor(p.id)} cây</span>
                  <span className="flex items-center gap-1"><Icon name="user" size={13} />{p.manager || "—"}</span>
                  <span className="flex items-center gap-1"><Icon name="user" size={13} />{p.client || "—"}</span>
                </div>
              </Card>
            </button>
          ))}
        </div>
      )}

      {openProject && (
        <ProjectDetail
          project={openProject}
          onClose={() => setOpenId(null)}
          onEdit={() => {
            setEditor({ mode: "edit", project: openProject });
            setOpenId(null);
          }}
          onDelete={() => {
            deleteProject(openProject.id);
            setOpenId(null);
          }}
        />
      )}

      {editor && (
        <ProjectEditor
          initial={editor.mode === "edit" ? editor.project : null}
          onClose={() => setEditor(null)}
          onSave={(input) => {
            if (editor.mode === "edit") updateProject(editor.project.id, input);
            else addProject(input);
            setEditor(null);
          }}
        />
      )}
    </div>
  );
}

function ProjectDetail({ project, onClose, onEdit, onDelete }: { project: Project; onClose: () => void; onEdit: () => void; onDelete: () => void }) {
  const { trees, logs } = useBpa();
  const projTrees = useMemo(() => trees.filter((t) => t.projectId === project.id), [trees, project.id]);
  const projLogs = useMemo(
    () => logs.filter((l) => l.linkType === "project" && l.linkId === project.id).slice(0, 12),
    [logs, project.id],
  );

  return (
    <Overlay
      title={project.name}
      onClose={onClose}
      footer={
        <div className="flex items-center gap-2">
          <Button variant="outline" block onClick={onEdit}>
            <Icon name="edit" size={16} />
            Chỉnh sửa
          </Button>
          <ConfirmButton onConfirm={onDelete} />
        </div>
      }
    >
      <Card className="p-4">
        <div className="flex items-center justify-between">
          <p className="text-[12px] text-[var(--bpa-muted)]">Tiến độ dự án</p>
          <span className="bpa-nums font-display text-lg font-extrabold text-[var(--bpa-green-deep)]">{project.progress}%</span>
        </div>
        <div className="mt-2">
          <ProgressBar value={project.progress} tone={project.progress >= 100 ? "green" : "lime"} />
        </div>
      </Card>

      <Card className="mt-3 divide-y divide-[var(--bpa-line-soft)]">
        <DetailRow icon="pin" label="Địa điểm" value={project.location || "—"} />
        <DetailRow icon="user" label="Khách hàng" value={project.client || "—"} />
        <DetailRow icon="user" label="Người phụ trách" value={project.manager || "—"} />
        <DetailRow icon="calendar" label="Ngày bắt đầu" value={dateLabel(project.startDate)} />
        <DetailRow icon="tree" label="Số lượng cây" value={`${projTrees.length} cây`} />
      </Card>

      <h3 className="mb-2 mt-5 font-display text-base font-bold text-[var(--bpa-ink)]">Cây thuộc dự án</h3>
      {projTrees.length === 0 ? (
        <p className="rounded-xl border border-dashed border-[var(--bpa-line)] p-4 text-center text-sm text-[var(--bpa-muted)]">Chưa gán cây nào cho dự án này.</p>
      ) : (
        <div className="flex flex-col gap-2">
          {projTrees.map((t) => (
            <Card key={t.id} className="flex items-center gap-3 p-2.5">
              <LeafArt hue={t.hue} health={t.health} size={40} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-bold text-[var(--bpa-ink)]">{t.name}</p>
                <p className="truncate text-[11px] text-[var(--bpa-faint)]">{t.code} · {t.location || "—"}</p>
              </div>
            </Card>
          ))}
        </div>
      )}

      <h3 className="mb-2 mt-5 font-display text-base font-bold text-[var(--bpa-ink)]">Nhật ký liên quan</h3>
      {projLogs.length === 0 ? (
        <p className="rounded-xl border border-dashed border-[var(--bpa-line)] p-4 text-center text-sm text-[var(--bpa-muted)]">Chưa có nhật ký cho dự án.</p>
      ) : (
        <div className="flex flex-col gap-2">
          {projLogs.map((l) => (
            <Card key={l.id} className="flex items-start gap-3 p-3">
              <span className="flex h-8 w-8 flex-none items-center justify-center rounded-lg bg-[var(--bpa-green-soft)] text-[var(--bpa-green-deep)]">
                <Icon name={CARE_META[l.type].icon as Parameters<typeof Icon>[0]["name"]} size={16} />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-[13px] font-bold text-[var(--bpa-ink)]">{CARE_META[l.type].label}</p>
                {l.note && <p className="bpa-pre text-[12px] text-[var(--bpa-muted)]">{l.note}</p>}
                <p className="mt-0.5 text-[11px] text-[var(--bpa-faint)]">{l.person || "—"} · {relativeTime(l.at)}</p>
              </div>
            </Card>
          ))}
        </div>
      )}
    </Overlay>
  );
}

function ProjectEditor({ initial, onClose, onSave }: { initial: Project | null; onClose: () => void; onSave: (input: ProjectInput) => void }) {
  const [name, setName] = useState(initial?.name ?? "");
  const [location, setLocation] = useState(initial?.location ?? "");
  const [client, setClient] = useState(initial?.client ?? "");
  const [startDate, setStartDate] = useState(initial?.startDate || todayIso());
  const [manager, setManager] = useState(initial?.manager ?? "");
  const [progress, setProgress] = useState(initial?.progress ?? 0);

  const valid = name.trim().length > 0;

  return (
    <Sheet title={initial ? "Chỉnh sửa dự án" : "Tạo dự án"} onClose={onClose}>
      <div className="flex flex-col gap-3">
        <Field label="Tên dự án">
          <TextInput value={name} onChange={(e) => setName(e.target.value)} placeholder="Ví dụ: Công viên Trung Tâm" />
        </Field>
        <Field label="Địa điểm">
          <TextInput value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Quận / khu vực" />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Khách hàng">
            <TextInput value={client} onChange={(e) => setClient(e.target.value)} placeholder="Chủ đầu tư" />
          </Field>
          <Field label="Người phụ trách">
            <TextInput value={manager} onChange={(e) => setManager(e.target.value)} placeholder="Kỹ sư / đội trưởng" />
          </Field>
        </div>
        <Field label="Ngày bắt đầu">
          <TextInput type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
        </Field>
        <Field label={`Tiến độ: ${progress}%`}>
          <input
            type="range"
            min={0}
            max={100}
            value={progress}
            onChange={(e) => setProgress(Number(e.target.value))}
            className="w-full accent-[var(--bpa-green)]"
          />
        </Field>
        <Button block disabled={!valid} onClick={() => onSave({ name, location, client, startDate, manager, progress })}>
          <Icon name="check" size={16} />
          {initial ? "Lưu thay đổi" : "Tạo dự án"}
        </Button>
      </div>
    </Sheet>
  );
}
