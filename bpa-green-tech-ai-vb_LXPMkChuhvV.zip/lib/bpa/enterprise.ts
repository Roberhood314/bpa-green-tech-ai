export type EmployeeRole = "Chủ doanh nghiệp" | "Giám đốc" | "Quản lý công trình" | "Quản lý nhân sự" | "Văn phòng" | "Công nhân";

export interface Employee {
  id: string; name: string; email: string; code: string; phone: string; title: string;
  role: EmployeeRole; team: string; permissions: string[]; verified: boolean; active: boolean; createdAt: number;
}
export interface Attendance { id: string; employeeId: string; action: "checkin" | "checkout"; at: number; lat: number | null; lon: number | null; }
export interface Device { id: string; name: string; type: "Cảm biến độ ẩm" | "Van tưới" | "Robot hỗ trợ"; zoneId: string; endpoint: string; automation: boolean; moisture: number | null; battery: number | null; min: number; target: number; maxMinutes: number; status: "online" | "offline" | "warning"; lastSeen: number | null; }
export interface Organization { name: string; representative: string; taxCode: string; email: string; phone: string; industry: string; address: string; description: string; }
export interface GovernanceRecord { id: string; employeeId: string; type: string; severity: string; title: string; detail: string; status: string; createdAt: number; }
export interface WorkReport { id: string; recipient: string; category: string; priority: string; title: string; content: string; status: string; createdAt: number; }
export interface WorkPackage { id: string; title: string; category: string; unit: string; planned: number; completed: number; unitCost: number; workers: number; tools: string; startDate: string; dueDate: string; status: string; note: string; }
export interface GrowthObservation { id: string; treeId: string; observedAt: string; height: number | null; diameter: number | null; canopy: number | null; imageName: string; note: string; analysis: string; createdAt: number; }

export interface EnterpriseState {
  employees: Employee[]; attendance: Attendance[]; devices: Device[]; organization: Organization;
  governance: GovernanceRecord[]; reports: WorkReport[]; work: WorkPackage[]; observations: GrowthObservation[];
}

export const EMPTY_ORGANIZATION: Organization = {
  name: "Công ty Kỹ Thuật Nông Nghiệp và Cây Xanh Bình Phước",
  representative: "", taxCode: "", email: "", phone: "",
  industry: "Cây xanh công trình, nông nghiệp và tưới thông minh", address: "", description: "",
};

export const EMPTY_ENTERPRISE: EnterpriseState = {
  employees: [], attendance: [], devices: [], organization: EMPTY_ORGANIZATION,
  governance: [], reports: [], work: [], observations: [],
};

const str = (v: unknown, n = 300) => typeof v === "string" ? v.trim().slice(0, n) : "";
const num = (v: unknown, min: number, max: number, fallback = 0) => Number.isFinite(Number(v)) ? Math.min(max, Math.max(min, Number(v))) : fallback;
const arr = (v: unknown) => Array.isArray(v) ? v : [];

export function sanitizeEnterprise(raw: unknown): EnterpriseState {
  const o = raw && typeof raw === "object" ? raw as Record<string, unknown> : {};
  const employees = arr(o.employees).slice(0, 2000).map((x, i) => { const e = x as Record<string, unknown>; return {
    id: str(e.id, 80) || `emp_${i}`, name: str(e.name, 120), email: str(e.email, 160).toLowerCase(), code: str(e.code, 40),
    phone: str(e.phone, 30), title: str(e.title, 100), role: str(e.role, 60) as EmployeeRole || "Công nhân", team: str(e.team, 100),
    permissions: arr(e.permissions).map(v => str(v, 40)).filter(Boolean).slice(0, 20), verified: !!e.verified, active: e.active !== false,
    createdAt: num(e.createdAt, 0, Date.now(), Date.now()),
  }; }).filter(e => e.name && e.email);
  const attendance = arr(o.attendance).slice(-5000).map((x, i) => { const a = x as Record<string, unknown>; return { id: str(a.id, 80) || `att_${i}`, employeeId: str(a.employeeId, 80), action: a.action === "checkout" ? "checkout" as const : "checkin" as const, at: num(a.at, 0, Date.now(), Date.now()), lat: a.lat == null ? null : num(a.lat, -90, 90), lon: a.lon == null ? null : num(a.lon, -180, 180) }; });
  const devices = arr(o.devices).slice(0, 1000).map((x, i) => { const d = x as Record<string, unknown>; return { id: str(d.id, 80) || `dev_${i}`, name: str(d.name, 120), type: str(d.type, 50) as Device["type"] || "Cảm biến độ ẩm", zoneId: str(d.zoneId, 80), endpoint: str(d.endpoint, 500), automation: !!d.automation, moisture: d.moisture == null ? null : num(d.moisture, 0, 100), battery: d.battery == null ? null : num(d.battery, 0, 100), min: num(d.min, 0, 100, 25), target: num(d.target, 0, 100, 45), maxMinutes: num(d.maxMinutes, 1, 30, 10), status: (["online","offline","warning"].includes(String(d.status)) ? d.status : "offline") as Device["status"], lastSeen: d.lastSeen == null ? null : num(d.lastSeen, 0, Date.now()) }; }).filter(d => d.name);
  const orgRaw = o.organization && typeof o.organization === "object" ? o.organization as Record<string, unknown> : {};
  const organization = { name: str(orgRaw.name, 180) || EMPTY_ORGANIZATION.name, representative: str(orgRaw.representative, 120), taxCode: str(orgRaw.taxCode, 40), email: str(orgRaw.email, 160), phone: str(orgRaw.phone, 30), industry: str(orgRaw.industry, 240) || EMPTY_ORGANIZATION.industry, address: str(orgRaw.address, 300), description: str(orgRaw.description, 3000) };
  const governance = arr(o.governance).slice(-2000).map((x, i) => { const r=x as Record<string,unknown>; return { id:str(r.id,80)||`gov_${i}`, employeeId:str(r.employeeId,80), type:str(r.type,60), severity:str(r.severity,60), title:str(r.title,200), detail:str(r.detail,3000), status:str(r.status,80)||"Đã gửi", createdAt:num(r.createdAt,0,Date.now(),Date.now()) }; }).filter(r=>r.title);
  const reports = arr(o.reports).slice(-3000).map((x,i)=>{const r=x as Record<string,unknown>;return{id:str(r.id,80)||`rep_${i}`,recipient:str(r.recipient,80),category:str(r.category,100),priority:str(r.priority,60),title:str(r.title,200),content:str(r.content,4000),status:str(r.status,80)||"Mới gửi",createdAt:num(r.createdAt,0,Date.now(),Date.now())};}).filter(r=>r.title);
  const work = arr(o.work).slice(-3000).map((x,i)=>{const w=x as Record<string,unknown>;return{id:str(w.id,80)||`work_${i}`,title:str(w.title,200),category:str(w.category,100),unit:str(w.unit,30)||"cây",planned:num(w.planned,0,1e9),completed:num(w.completed,0,1e9),unitCost:num(w.unitCost,0,1e12),workers:num(w.workers,0,100000),tools:str(w.tools,500),startDate:str(w.startDate,10),dueDate:str(w.dueDate,10),status:str(w.status,60)||"Kế hoạch",note:str(w.note,2000)};}).filter(w=>w.title);
  const observations = arr(o.observations).slice(-3000).map((x,i)=>{const g=x as Record<string,unknown>;return{id:str(g.id,80)||`obs_${i}`,treeId:str(g.treeId,80),observedAt:str(g.observedAt,10),height:g.height==null?null:num(g.height,0,1000),diameter:g.diameter==null?null:num(g.diameter,0,10000),canopy:g.canopy==null?null:num(g.canopy,0,1000),imageName:str(g.imageName,240),note:str(g.note,2000),analysis:str(g.analysis,5000),createdAt:num(g.createdAt,0,Date.now(),Date.now())};});
  return { employees, attendance, devices, organization, governance, reports, work, observations };
}
