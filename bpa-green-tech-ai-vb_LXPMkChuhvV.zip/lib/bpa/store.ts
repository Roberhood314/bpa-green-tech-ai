// Durable per-user storage helpers for BPA Green Tech AI.
// Wraps the Pi user-state surface with an in-memory fallback and a rate-limit-aware writer.

import type { SDKLiteInstance } from "@/lib/sdklite-types";

export interface StoreApi {
  get: (key: string) => Promise<unknown>;
  set: (key: string, blob: Record<string, unknown>) => Promise<void>;
}

export function makeMemStore(): StoreApi {
  const mem = new Map<string, Record<string, unknown>>();
  return {
    async get(key) {
      return mem.has(key) ? { blob: mem.get(key) } : null;
    },
    async set(key, blob) {
      mem.set(key, blob);
    },
  };
}

export function storeOf(sdk: SDKLiteInstance | null): StoreApi {
  if (!sdk || !sdk.state) return makeMemStore();
  return {
    get: (key) => sdk.state.get(key),
    set: (key, blob) => sdk.state.set(key, blob),
  };
}

const MIN_PER_KEY = 5200;
const MIN_ACROSS = 1100;

interface Pending {
  build: () => Record<string, unknown>;
  timer: ReturnType<typeof setTimeout> | null;
  lastWrite: number;
  backoff: number;
  inFlight: boolean;
}

export class KeyWriter {
  private store: StoreApi;
  private onTrouble: (v: boolean) => void;
  private map = new Map<string, Pending>();
  private static lastAnyWrite = 0;

  constructor(store: StoreApi, onTrouble: (v: boolean) => void) {
    this.store = store;
    this.onTrouble = onTrouble;
  }

  schedule(key: string, build: () => Record<string, unknown>, immediate = false) {
    let p = this.map.get(key);
    if (!p) {
      p = { build, timer: null, lastWrite: 0, backoff: 0, inFlight: false };
      this.map.set(key, p);
    } else {
      p.build = build;
    }
    if (p.timer) clearTimeout(p.timer);

    const now = Date.now();
    const sinceKey = now - p.lastWrite;
    const sinceAny = now - KeyWriter.lastAnyWrite;
    let delay = immediate ? 0 : 350;
    delay = Math.max(delay, MIN_PER_KEY - sinceKey, MIN_ACROSS - sinceAny, p.backoff);

    p.timer = setTimeout(() => this.flush(key), Math.max(0, delay));
  }

  private async flush(key: string) {
    const p = this.map.get(key);
    if (!p || p.inFlight) return;
    p.inFlight = true;
    p.timer = null;
    const blob = p.build();
    try {
      await this.store.set(key, blob);
      p.lastWrite = Date.now();
      KeyWriter.lastAnyWrite = p.lastWrite;
      p.backoff = 0;
      p.inFlight = false;
      this.onTrouble(false);
    } catch {
      p.inFlight = false;
      p.backoff = p.backoff ? Math.min(30000, Math.round(p.backoff * 1.8)) : 3000;
      this.onTrouble(true);
      p.timer = setTimeout(() => this.flush(key), p.backoff);
    }
  }

  flushNow() {
    for (const key of this.map.keys()) {
      const p = this.map.get(key);
      if (p && !p.inFlight) {
        if (p.timer) clearTimeout(p.timer);
        void this.flush(key);
      }
    }
  }
}
