// BPA Green Tech AI — types, seed data, helpers and sanitizers.
// All user-facing strings are Vietnamese.

export type ModuleId =
  | "dashboard"
  | "trees"
  | "projects"
  | "irrigation"
  | "carelog"
  | "acceptance"
  | "assistant"
  | "personnel"
  | "iot"
  | "more"
  | "company"
  | "governance"
  | "reports"
  | "operations"
  | "weather"
  | "growth";

export type HealthId = "khoe" | "theo_doi" | "yeu" | "benh";
export type ZoneStatus = "tuoi" | "tam_dung" | "loi";
export type CareType = "tuoi" | "bon_phan" | "cat_tia" | "sau_benh";
export type ApprovalStatus = "cho_duyet" | "da_duyet" | "tu_choi";
export type AlertKind = "sau_benh" | "thieu_nuoc" | "thiet_bi";

export interface HealthMeta {
  id: HealthId;
  label: string;
  varName: string;
  softVar: string;
}
export const HEALTH_META: Record<HealthId, HealthMeta> = {
  khoe: { id: "khoe", label: "Khỏe", varName: "--bpa-khoe", softVar: "--bpa-khoe-soft" },
  theo_doi: { id: "theo_doi", label: "Cần theo dõi", varName: "--bpa-theodoi", softVar: "--bpa-theodoi-soft" },
  yeu: { id: "yeu", label: "Yếu", varName: "--bpa-yeu", softVar: "--bpa-yeu-soft" },
  benh: { id: "benh", label: "Bệnh", varName: "--bpa-benh", softVar: "--bpa-benh-soft" },
};
export const HEALTH_ORDER: HealthId[] = ["khoe", "theo_doi", "yeu", "benh"];

export const ZONE_STATUS_META: Record<ZoneStatus, { label: string; varName: string; softVar: string }> = {
  tuoi: { label: "Đang tưới", varName: "--bpa-water", softVar: "--bpa-water-soft" },
  tam_dung: { label: "Tạm dừng", varName: "--bpa-muted", softVar: "--bpa-panel-2" },
  loi: { label: "Lỗi thiết bị", varName: "--bpa-error", softVar: "--bpa-error-soft" },
};

export const CARE_META: Record<CareType, { label: string; icon: string }> = {
  tuoi: { label: "Tưới nước", icon: "droplet" },
  bon_phan: { label: "Bón phân", icon: "fertilizer" },
  cat_tia: { label: "Cắt tỉa", icon: "scissors" },
  sau_benh: { label: "Xử lý sâu bệnh", icon: "bug" },
};
export const CARE_ORDER: CareType[] = ["tuoi", "bon_phan", "cat_tia", "sau_benh"];

export const APPROVAL_META: Record<ApprovalStatus, { label: string; varName: string; softVar: string }> = {
  cho_duyet: { label: "Chờ duyệt", varName: "--bpa-warn", softVar: "--bpa-warn-soft" },
  da_duyet: { label: "Đã duyệt", varName: "--bpa-khoe", softVar: "--bpa-khoe-soft" },
  tu_choi: { label: "Từ chối", varName: "--bpa-error", softVar: "--bpa-error-soft" },
};

export interface Tree {
  id: string;
  code: string;
  name: string;
  species: string;
  plantedDate: string; // yyyy-mm-dd
  location: string;
  health: HealthId;
  hue: number;
  projectId: string | null;
  createdAt: number;
}

export interface Project {
  id: string;
  name: string;
  location: string;
  client: string;
  startDate: string;
  progress: number; // 0-100
  manager: string;
  createdAt: number;
}

export interface Zone {
  id: string;
  name: string;
  moisture: number; // 0-100
  scheduleTime: string; // HH:mm
  durationMin: number;
  waterLiters: number;
  status: ZoneStatus;
  enabled: boolean;
  createdAt: number;
}

export interface CareLog {
  id: string;
  type: CareType;
  person: string;
  at: number;
  note: string;
  linkType: "tree" | "zone" | "project" | "none";
  linkId: string | null;
  createdAt: number;
}

export interface AcceptanceItem {
  name: string;
  quantity: number;
  unit: string;
}

export interface Acceptance {
  id: string;
  name: string;
  projectId: string | null;
  items: AcceptanceItem[];
  status: ApprovalStatus;
  signer: string;
  note: string;
  at: number;
  createdAt: number;
}

export interface ChatMsg {
  role: "user" | "assistant";
  text: string;
  at: number;
}

export interface Alert {
  id: string;
  kind: AlertKind;
  message: string;
  detail: string;
  severity: "high" | "med";
}

export interface Prefs {
  tab: ModuleId;
}

export const CARE_TYPES = CARE_ORDER;
export const ZONE_UNITS = "lít";

// caps
export const MAX_TREES = 200;
export const MAX_PROJECTS = 80;
export const MAX_ZONES = 60;
export const MAX_LOGS = 240;
export const MAX_ACCEPTANCE = 120;
export const MAX_CHAT = 40;
export const MAX_ITEMS = 30;

/* ---------------- helpers ---------------- */

export function makeId(prefix = "id"): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

export function hueFor(seed: string): number {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h) % 360;
}

export function todayIso(): string {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

export function dateLabel(iso: string): string {
  if (!iso) return "—";
  const parts = iso.split("-");
  if (parts.length !== 3) return iso;
  return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

export function relativeTime(at: number, now = Date.now()): string {
  const diff = Math.max(0, now - at);
  const m = Math.floor(diff / 60000);
  if (m < 1) return "Vừa xong";
  if (m < 60) return `${m} phút trước`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} giờ trước`;
  const d = Math.floor(h / 24);
  if (d < 30) return `${d} ngày trước`;
  const mo = Math.floor(d / 30);
  return `${mo} tháng trước`;
}

export function timeLabel(at: number): string {
  const d = new Date(at);
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${hh}:${mm} · ${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`;
}

export function fold(s: string): string {
  return s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d")
    .replace(/Đ/g, "D")
    .toLowerCase();
}

export function formatInt(n: number): string {
  return Math.round(n).toLocaleString("vi-VN");
}

export function healthLabel(id: HealthId): string {
  return HEALTH_META[id]?.label ?? id;
}

/* ---------------- derived ---------------- */

export function healthPercent(trees: Tree[]): number {
  if (trees.length === 0) return 0;
  const healthy = trees.filter((t) => t.health === "khoe").length;
  return Math.round((healthy / trees.length) * 100);
}

export function buildAlerts(trees: Tree[], zones: Zone[]): Alert[] {
  const out: Alert[] = [];
  for (const t of trees) {
    if (t.health === "benh") {
      out.push({
        id: `al_tree_${t.id}`,
        kind: "sau_benh",
        message: `Cây ${t.name} (${t.code}) có dấu hiệu sâu bệnh`,
        detail: `${t.location} · cần xử lý sớm`,
        severity: "high",
      });
    }
  }
  for (const z of zones) {
    if (z.status === "loi") {
      out.push({
        id: `al_zone_err_${z.id}`,
        kind: "thiet_bi",
        message: `Thiết bị khu ${z.name} báo lỗi`,
        detail: "Kiểm tra van và cảm biến",
        severity: "high",
      });
    } else if (z.moisture < 35) {
      out.push({
        id: `al_zone_dry_${z.id}`,
        kind: "thieu_nuoc",
        message: `Khu ${z.name} độ ẩm thấp (${Math.round(z.moisture)}%)`,
        detail: "Đề xuất tưới bổ sung",
        severity: z.moisture < 25 ? "high" : "med",
      });
    }
  }
  for (const t of trees) {
    if (t.health === "yeu") {
      out.push({
        id: `al_tree_weak_${t.id}`,
        kind: "sau_benh",
        message: `Cây ${t.name} (${t.code}) đang yếu`,
        detail: `${t.location} · theo dõi và chăm sóc`,
        severity: "med",
      });
    }
  }
  return out.sort((a, b) => (a.severity === b.severity ? 0 : a.severity === "high" ? -1 : 1));
}

/* ---------------- seed ---------------- */

export function buildSeed(): {
  trees: Tree[];
  projects: Project[];
  zones: Zone[];
  logs: CareLog[];
  acceptances: Acceptance[];
} {
  const now = Date.now();
  const day = 86400000;

  const p1: Project = { id: "prj_cvxanh", name: "Công viên Trung Tâm", location: "Q.1, TP.HCM", client: "UBND Quận 1", startDate: "2025-03-12", progress: 72, manager: "Nguyễn Văn Minh", createdAt: now - 40 * day };
  const p2: Project = { id: "prj_khudothi", name: "Cảnh quan Khu đô thị Xanh", location: "Thủ Đức, TP.HCM", client: "Cty CP Đầu tư Xanh", startDate: "2025-06-01", progress: 45, manager: "Trần Thị Hoa", createdAt: now - 20 * day };
  const p3: Project = { id: "prj_daihoc", name: "Sân trường Đại học Nông Lâm", location: "Thủ Đức, TP.HCM", client: "ĐH Nông Lâm", startDate: "2025-08-20", progress: 18, manager: "Lê Quốc Bảo", createdAt: now - 6 * day };
  const projects = [p1, p2, p3];

  const treeSpecs: Array<[string, string, HealthId, string, string, string | null]> = [
    ["Bằng Lăng", "Lagerstroemia", "khoe", "2025-03-15", "Lối vào chính", p1.id],
    ["Sao Đen", "Hopea odorata", "khoe", "2025-03-16", "Trục đường số 2", p1.id],
    ["Phượng Vĩ", "Delonix regia", "theo_doi", "2025-06-10", "Quảng trường trung tâm", p2.id],
    ["Osaka Vàng", "Cassia fistula", "yeu", "2025-06-12", "Ven hồ điều hòa", p2.id],
    ["Lộc Vừng", "Barringtonia acutangula", "benh", "2025-04-01", "Vườn dạo bộ", p1.id],
    ["Muồng Hoàng Yến", "Cassia", "khoe", "2025-08-22", "Sân trước hội trường", p3.id],
    ["Giáng Hương", "Pterocarpus", "khoe", "2025-08-23", "Bãi cỏ phía Đông", p3.id],
    ["Me Tây", "Samanea saman", "theo_doi", "2025-05-02", "Bãi đỗ xe", null],
  ];
  const trees: Tree[] = treeSpecs.map((s, i) => ({
    id: `tree_${i + 1}`,
    code: `C-${String(i + 1).padStart(4, "0")}`,
    name: s[0],
    species: s[1],
    health: s[2],
    plantedDate: s[3],
    location: s[4],
    projectId: s[5],
    hue: hueFor(s[0]),
    createdAt: now - (30 - i) * day,
  }));

  const zones: Zone[] = [
    { id: "zone_1", name: "A - Lối vào", moisture: 68, scheduleTime: "05:30", durationMin: 15, waterLiters: 240, status: "tuoi", enabled: true, createdAt: now - 30 * day },
    { id: "zone_2", name: "B - Quảng trường", moisture: 42, scheduleTime: "06:00", durationMin: 20, waterLiters: 360, status: "tam_dung", enabled: true, createdAt: now - 25 * day },
    { id: "zone_3", name: "C - Ven hồ", moisture: 28, scheduleTime: "18:00", durationMin: 18, waterLiters: 300, status: "tam_dung", enabled: true, createdAt: now - 20 * day },
    { id: "zone_4", name: "D - Bãi cỏ Đông", moisture: 55, scheduleTime: "05:45", durationMin: 12, waterLiters: 180, status: "loi", enabled: false, createdAt: now - 12 * day },
  ];

  const logs: CareLog[] = [
    { id: "log_1", type: "tuoi", person: "Nguyễn Văn Minh", at: now - 2 * 3600000, note: "Tưới khu lối vào, độ ẩm ổn định.", linkType: "zone", linkId: "zone_1", createdAt: now - 2 * 3600000 },
    { id: "log_2", type: "cat_tia", person: "Trần Thị Hoa", at: now - day, note: "Cắt tỉa tạo tán cây Bằng Lăng.", linkType: "tree", linkId: "tree_1", createdAt: now - day },
    { id: "log_3", type: "sau_benh", person: "Lê Quốc Bảo", at: now - 2 * day, note: "Phun thuốc phòng sâu đục thân cây Lộc Vừng.", linkType: "tree", linkId: "tree_5", createdAt: now - 2 * day },
    { id: "log_4", type: "bon_phan", person: "Nguyễn Văn Minh", at: now - 4 * day, note: "Bón phân hữu cơ cho khu quảng trường.", linkType: "project", linkId: "prj_khudothi", createdAt: now - 4 * day },
  ];

  const acceptances: Acceptance[] = [
    {
      id: "acc_1",
      name: "Nghiệm thu trồng cây đợt 1 - Công viên Trung Tâm",
      projectId: p1.id,
      items: [
        { name: "Trồng cây Bằng Lăng", quantity: 24, unit: "cây" },
        { name: "Trồng cây Sao Đen", quantity: 18, unit: "cây" },
        { name: "Trải thảm cỏ", quantity: 320, unit: "m²" },
      ],
      status: "da_duyet",
      signer: "Nguyễn Văn Minh",
      note: "Cây sinh trưởng tốt, đạt yêu cầu kỹ thuật.",
      at: now - 10 * day,
      createdAt: now - 10 * day,
    },
    {
      id: "acc_2",
      name: "Nghiệm thu hệ thống tưới - Khu đô thị Xanh",
      projectId: p2.id,
      items: [
        { name: "Lắp đặt đường ống tưới", quantity: 480, unit: "m" },
        { name: "Lắp béc phun", quantity: 60, unit: "cái" },
      ],
      status: "cho_duyet",
      signer: "Trần Thị Hoa",
      note: "",
      at: now - 3 * day,
      createdAt: now - 3 * day,
    },
  ];

  return { trees, projects, zones, logs, acceptances };
}

/* ---------------- knowledge library (assistant) ---------------- */

export interface KnowledgeItem {
  id: string;
  title: string;
  category: string;
  icon: string;
  body: string;
  ask: string;
}
export const KNOWLEDGE: KnowledgeItem[] = [
  {
    id: "kn_water",
    title: "Nguyên tắc tưới nước cho cây xanh đô thị",
    category: "Tưới tiêu",
    icon: "droplet",
    body: "Tưới vào sáng sớm (5-7h) hoặc chiều mát (17-18h) để giảm bốc hơi. Cây mới trồng cần tưới đều mỗi ngày trong 2-4 tuần đầu. Duy trì độ ẩm đất 60-75%; dưới 35% cần tưới bổ sung ngay.",
    ask: "Tư vấn lịch tưới nước hợp lý cho cây xanh đô thị trong mùa khô.",
  },
  {
    id: "kn_fertilize",
    title: "Lịch bón phân theo mùa",
    category: "Dinh dưỡng",
    icon: "fertilizer",
    body: "Đầu mùa mưa bón phân hữu cơ hoai mục để cây phát triển tán. Giữa mùa dùng NPK cân đối 16-16-8. Trước mùa khô bổ sung kali giúp cây chống chịu. Bón cách gốc 30-50cm, tránh sát gốc.",
    ask: "Đề xuất lịch bón phân theo mùa cho cây công trình.",
  },
  {
    id: "kn_pest",
    title: "Nhận biết và xử lý sâu bệnh thường gặp",
    category: "Bảo vệ thực vật",
    icon: "bug",
    body: "Lá vàng loang lổ, có đốm nâu là dấu hiệu nấm bệnh. Cành khô, mùn cưa dưới gốc là sâu đục thân. Cắt bỏ phần bệnh, thu gom tiêu hủy, phun thuốc sinh học và cải thiện thoát nước quanh gốc.",
    ask: "Cây của tôi có lá vàng và đốm nâu, nên xử lý sâu bệnh thế nào?",
  },
  {
    id: "kn_prune",
    title: "Kỹ thuật cắt tỉa tạo tán an toàn",
    category: "Cắt tỉa",
    icon: "scissors",
    body: "Tỉa cành khô, cành giao chéo và cành sà thấp gây mất an toàn. Vết cắt nghiêng, sát cổ cành, không để lại mấu. Không tỉa quá 25% tán trong một lần. Tỉa vào đầu mùa mưa để cây phục hồi nhanh.",
    ask: "Hướng dẫn kỹ thuật cắt tỉa tạo tán an toàn cho cây công trình.",
  },
  {
    id: "kn_health",
    title: "Đánh giá sức khỏe cây định kỳ",
    category: "Theo dõi",
    icon: "leaf",
    body: "Kiểm tra định kỳ: màu và mật độ lá, độ nghiêng thân, vết nứt vỏ, hệ rễ nổi. Ghi nhật ký theo từng cây để phát hiện xu hướng suy yếu sớm và có biện pháp can thiệp kịp thời.",
    ask: "Làm sao đánh giá sức khỏe cây định kỳ hiệu quả?",
  },
];

export const SUGGESTED_PROMPTS: string[] = [
  "Cây nào trong hệ thống đang cần ưu tiên chăm sóc nhất?",
  "Đề xuất lịch tưới tối ưu cho các khu vực độ ẩm thấp.",
  "Dấu hiệu nhận biết cây bị thiếu nước là gì?",
  "Lập báo cáo nhanh về sức khỏe cây và tiến độ dự án.",
];

export interface PriorityTask {
  text: string;
  tone: string; // css var base with a matching -soft
}

export function buildPriorityTasks(trees: Tree[], zones: Zone[], projects: Project[]): PriorityTask[] {
  const high: PriorityTask[] = [];
  const med: PriorityTask[] = [];

  for (const t of trees) {
    if (t.health === "benh") high.push({ text: `Xử lý sâu bệnh cho cây ${t.name} (${t.code}) tại ${t.location || "hiện trường"}.`, tone: "--bpa-error" });
  }
  for (const z of zones) {
    if (z.status === "loi") high.push({ text: `Kiểm tra, khắc phục thiết bị tưới khu ${z.name}.`, tone: "--bpa-error" });
  }
  for (const z of zones) {
    if (z.status !== "loi" && z.moisture < 35) med.push({ text: `Tưới bổ sung khu ${z.name} (độ ẩm ${Math.round(z.moisture)}%).`, tone: "--bpa-water" });
  }
  for (const t of trees) {
    if (t.health === "yeu") med.push({ text: `Theo dõi và tăng cường chăm sóc cây ${t.name} (${t.code}).`, tone: "--bpa-warn" });
  }
  for (const p of projects) {
    if (p.progress < 100 && p.progress >= 90) med.push({ text: `Hoàn thiện & chuẩn bị nghiệm thu dự án ${p.name} (${p.progress}%).`, tone: "--bpa-khoe" });
  }

  return [...high, ...med].slice(0, 8);
}

/* ---------------- sanitizers ---------------- */

export function extractObject(rec: unknown): Record<string, unknown> | null {
  let cur: any = rec;
  for (let i = 0; i < 4; i++) {
    if (!cur || typeof cur !== "object") return null;
    if ("blob" in cur && cur.blob && typeof cur.blob === "object") {
      cur = cur.blob;
      continue;
    }
    return cur as Record<string, unknown>;
  }
  return cur && typeof cur === "object" ? (cur as Record<string, unknown>) : null;
}

function extractItems(rec: unknown): unknown[] {
  const obj = extractObject(rec);
  if (!obj) return Array.isArray(rec) ? (rec as unknown[]) : [];
  if (Array.isArray((obj as any).items)) return (obj as any).items;
  return [];
}

function cleanStr(v: unknown, max = 400): string {
  if (typeof v !== "string") return "";
  // strip control chars, keep newlines/tabs
  let out = "";
  for (const ch of v) {
    const c = ch.charCodeAt(0);
    if (c === 9 || c === 10 || c === 13 || c >= 32) out += ch;
  }
  return out.slice(0, max);
}

function toNum(v: unknown, def = 0): number {
  const n = typeof v === "number" ? v : parseFloat(String(v));
  return Number.isFinite(n) ? n : def;
}

function clampPct(v: unknown): number {
  return Math.max(0, Math.min(100, Math.round(toNum(v, 0))));
}

function pick<T extends string>(v: unknown, allowed: readonly T[], def: T): T {
  return allowed.includes(v as T) ? (v as T) : def;
}

export function sanitizeTree(raw: unknown): Tree | null {
  const o = extractObject(raw);
  if (!o) return null;
  const id = cleanStr(o.id, 64);
  if (!id) return null;
  const name = cleanStr(o.name, 80) || "Cây";
  return {
    id,
    code: cleanStr(o.code, 32) || "C-0000",
    name,
    species: cleanStr(o.species, 80),
    plantedDate: cleanStr(o.plantedDate, 12),
    location: cleanStr(o.location, 120),
    health: pick(o.health, HEALTH_ORDER, "khoe"),
    hue: Number.isFinite(o.hue as number) ? (o.hue as number) : hueFor(name),
    projectId: o.projectId ? cleanStr(o.projectId, 64) : null,
    createdAt: toNum(o.createdAt, Date.now()),
  };
}
export function sanitizeTrees(raw: unknown): Tree[] {
  return extractItems(raw)
    .map(sanitizeTree)
    .filter((t): t is Tree => !!t)
    .slice(0, MAX_TREES);
}

export function sanitizeProject(raw: unknown): Project | null {
  const o = extractObject(raw);
  if (!o) return null;
  const id = cleanStr(o.id, 64);
  if (!id) return null;
  return {
    id,
    name: cleanStr(o.name, 120) || "Dự án",
    location: cleanStr(o.location, 120),
    client: cleanStr(o.client, 120),
    startDate: cleanStr(o.startDate, 12),
    progress: clampPct(o.progress),
    manager: cleanStr(o.manager, 80),
    createdAt: toNum(o.createdAt, Date.now()),
  };
}
export function sanitizeProjects(raw: unknown): Project[] {
  return extractItems(raw).map(sanitizeProject).filter((p): p is Project => !!p).slice(0, MAX_PROJECTS);
}

export function sanitizeZone(raw: unknown): Zone | null {
  const o = extractObject(raw);
  if (!o) return null;
  const id = cleanStr(o.id, 64);
  if (!id) return null;
  return {
    id,
    name: cleanStr(o.name, 80) || "Khu tưới",
    moisture: clampPct(o.moisture),
    scheduleTime: cleanStr(o.scheduleTime, 5) || "06:00",
    durationMin: Math.max(1, Math.min(240, Math.round(toNum(o.durationMin, 15)))),
    waterLiters: Math.max(0, Math.round(toNum(o.waterLiters, 0))),
    status: pick(o.status, ["tuoi", "tam_dung", "loi"] as const, "tam_dung"),
    enabled: o.enabled !== false,
    createdAt: toNum(o.createdAt, Date.now()),
  };
}
export function sanitizeZones(raw: unknown): Zone[] {
  return extractItems(raw).map(sanitizeZone).filter((z): z is Zone => !!z).slice(0, MAX_ZONES);
}

export function sanitizeLog(raw: unknown): CareLog | null {
  const o = extractObject(raw);
  if (!o) return null;
  const id = cleanStr(o.id, 64);
  if (!id) return null;
  return {
    id,
    type: pick(o.type, CARE_ORDER, "tuoi"),
    person: cleanStr(o.person, 80),
    at: toNum(o.at, Date.now()),
    note: cleanStr(o.note, 600),
    linkType: pick(o.linkType, ["tree", "zone", "project", "none"] as const, "none"),
    linkId: o.linkId ? cleanStr(o.linkId, 64) : null,
    createdAt: toNum(o.createdAt, Date.now()),
  };
}
export function sanitizeLogs(raw: unknown): CareLog[] {
  return extractItems(raw)
    .map(sanitizeLog)
    .filter((l): l is CareLog => !!l)
    .sort((a, b) => b.at - a.at)
    .slice(0, MAX_LOGS);
}

function sanitizeItem(raw: unknown): AcceptanceItem | null {
  const o = extractObject(raw);
  if (!o) return null;
  const name = cleanStr(o.name, 120);
  if (!name) return null;
  return { name, quantity: Math.max(0, toNum(o.quantity, 0)), unit: cleanStr(o.unit, 20) || "cái" };
}

export function sanitizeAcceptance(raw: unknown): Acceptance | null {
  const o = extractObject(raw);
  if (!o) return null;
  const id = cleanStr(o.id, 64);
  if (!id) return null;
  const items = Array.isArray(o.items)
    ? (o.items as unknown[]).map(sanitizeItem).filter((i): i is AcceptanceItem => !!i).slice(0, MAX_ITEMS)
    : [];
  return {
    id,
    name: cleanStr(o.name, 160) || "Biên bản nghiệm thu",
    projectId: o.projectId ? cleanStr(o.projectId, 64) : null,
    items,
    status: pick(o.status, ["cho_duyet", "da_duyet", "tu_choi"] as const, "cho_duyet"),
    signer: cleanStr(o.signer, 80),
    note: cleanStr(o.note, 600),
    at: toNum(o.at, Date.now()),
    createdAt: toNum(o.createdAt, Date.now()),
  };
}
export function sanitizeAcceptances(raw: unknown): Acceptance[] {
  return extractItems(raw)
    .map(sanitizeAcceptance)
    .filter((a): a is Acceptance => !!a)
    .sort((a, b) => b.at - a.at)
    .slice(0, MAX_ACCEPTANCE);
}

export function sanitizeChat(raw: unknown): ChatMsg[] {
  return extractItems(raw)
    .map((m) => {
      const o = extractObject(m);
      if (!o) return null;
      const role = o.role === "assistant" ? "assistant" : "user";
      const text = cleanStr(o.text, 4000);
      if (!text) return null;
      return { role, text, at: toNum(o.at, Date.now()) } as ChatMsg;
    })
    .filter((m): m is ChatMsg => !!m)
    .slice(-MAX_CHAT);
}

export function sanitizePrefs(raw: unknown): Prefs {
  const o = extractObject(raw);
  const allowed: ModuleId[] = ["dashboard", "trees", "projects", "irrigation", "carelog", "acceptance", "assistant", "personnel", "iot", "more", "company", "governance", "reports", "operations", "weather", "growth"];
  return { tab: pick(o?.tab, allowed, "dashboard") };
}

/* to-blob wrappers */
export const treesToBlob = (items: Tree[]) => ({ items });
export const projectsToBlob = (items: Project[]) => ({ items });
export const zonesToBlob = (items: Zone[]) => ({ items });
export const logsToBlob = (items: CareLog[]) => ({ items });
export const acceptancesToBlob = (items: Acceptance[]) => ({ items });
export const chatToBlob = (items: ChatMsg[]) => ({ items });
export const prefsToBlob = (p: Prefs) => ({ ...p });
