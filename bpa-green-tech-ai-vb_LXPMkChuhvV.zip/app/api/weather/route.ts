export const runtime = "nodejs";
export const revalidate = 600;
import { NextResponse } from "next/server";

const finite = (value: string | null, min: number, max: number) => {
  const n = Number(value);
  return Number.isFinite(n) && n >= min && n <= max ? n : null;
};

export async function GET(request: Request) {
  const url = new URL(request.url), lat = finite(url.searchParams.get("lat"), -90, 90), lon = finite(url.searchParams.get("lon"), -180, 180);
  if (lat === null || lon === null) return NextResponse.json({ error: "Tọa độ không hợp lệ." }, { status: 400 });
  try {
    const endpoint = new URL("https://api.open-meteo.com/v1/forecast");
    endpoint.searchParams.set("latitude", lat.toFixed(5)); endpoint.searchParams.set("longitude", lon.toFixed(5));
    endpoint.searchParams.set("current", "temperature_2m,relative_humidity_2m,wind_speed_10m");
    endpoint.searchParams.set("hourly", "precipitation"); endpoint.searchParams.set("forecast_days", "1"); endpoint.searchParams.set("timezone", "auto");
    const response = await fetch(endpoint, { signal: AbortSignal.timeout(12000), next: { revalidate: 600 } });
    if (!response.ok) throw new Error("weather upstream");
    const data = await response.json() as { current?: { temperature_2m?: number; relative_humidity_2m?: number; wind_speed_10m?: number }; hourly?: { precipitation?: number[] } };
    const current = data.current; if (!current) throw new Error("missing current");
    const rain = (data.hourly?.precipitation || []).slice(0, 6).reduce((n, v) => n + (Number(v) || 0), 0);
    const temperature = Number(current.temperature_2m), humidity = Number(current.relative_humidity_2m), wind = Number(current.wind_speed_10m);
    const advice = rain >= 2 ? "Có dự báo mưa. Kiểm tra độ ẩm đất trước khi quyết định tưới." : temperature >= 35 ? "Nhiệt độ cao. Kiểm tra độ ẩm đất và dấu hiệu héo; không tưới chỉ dựa trên dự báo." : "Theo dõi cảm biến đất và nhu cầu từng loài; dữ liệu thời tiết không thay thế kiểm tra hiện trường.";
    return NextResponse.json({ lat, lon, temperature, humidity, wind, rain: Math.round(rain * 10) / 10, advice, source: "Open-Meteo", fetchedAt: new Date().toISOString() });
  } catch { return NextResponse.json({ error: "Chưa lấy được dữ liệu thời tiết. Vui lòng thử lại sau." }, { status: 502 }); }
}
