"use client";

import { BpaApp } from "@/components/bpa-app";

export default function HomePage() {
  return <BpaApp />;
}
