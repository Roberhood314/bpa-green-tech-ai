import type React from "react";
import type { Metadata, Viewport } from "next";
import { GeistMono } from "geist/font/mono";
import { Be_Vietnam_Pro, Plus_Jakarta_Sans } from "next/font/google";
import { AppWrapper } from "@/components/app-wrapper";
import "./globals.css";

const beVietnam = Be_Vietnam_Pro({
  subsets: ["latin", "vietnamese"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-bpa-sans",
});

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin", "vietnamese"],
  weight: ["600", "700", "800"],
  variable: "--font-bpa-display",
});

export const metadata: Metadata = {
  title: "BPA Green Tech AI",
  description: "Nền tảng AI quản lý cây xanh, công trình, nhân sự, IoT và tưới thông minh.",
  applicationName: "BPA Green Tech AI",
  generator: "BPA GreenTech",
  icons: { icon: "/icon.svg", apple: "/apple-icon.png" },
};

export const viewport: Viewport = {
  themeColor: "#2f6b3f",
  userScalable: false,
  maximumScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="vi"
      className={`bg-background ${beVietnam.variable} ${jakarta.variable} ${GeistMono.variable}`}
    >
      <body>
        <AppWrapper>{children}</AppWrapper>
      </body>
    </html>
  );
}
