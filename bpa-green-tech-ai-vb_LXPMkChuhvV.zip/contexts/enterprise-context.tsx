"use client";
import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { usePiAuth } from "@/contexts/pi-auth-context";
import { makeId } from "@/lib/bpa/data";
import { EMPTY_ENTERPRISE, sanitizeEnterprise, type EnterpriseState } from "@/lib/bpa/enterprise";
import { storeOf, KeyWriter } from "@/lib/bpa/store";

type Kind = Exclude<keyof EnterpriseState, "organization">;
interface EnterpriseContextValue { state: EnterpriseState; ready: boolean; storageTrouble: boolean; add: (kind: Kind, item: Record<string, unknown>) => void; update: (kind: Kind, id: string, patch: Record<string, unknown>) => void; setOrganization: (value: EnterpriseState["organization"]) => void; }
const Ctx = createContext<EnterpriseContextValue | null>(null);
const KEY = "bpa.enterprise.v1";

export function EnterpriseProvider({ children }: { children: ReactNode }) {
  const { sdk } = usePiAuth();
  const [state, setState] = useState<EnterpriseState>(EMPTY_ENTERPRISE), [ready, setReady] = useState(false), [storageTrouble, setStorageTrouble] = useState(false);
  const ref = useRef(state), writer = useRef<KeyWriter | null>(null);
  useEffect(() => { ref.current = state; }, [state]);
  useEffect(() => { let live = true; const store = storeOf(sdk); writer.current = new KeyWriter(store, setStorageTrouble); void store.get(KEY).then(raw => { if (!live) return; const blob = raw && typeof raw === "object" && "blob" in raw ? (raw as {blob: unknown}).blob : raw; const next = sanitizeEnterprise(blob); ref.current = next; setState(next); setReady(true); }).catch(() => { if (live) { setState(EMPTY_ENTERPRISE); setReady(true); setStorageTrouble(true); } }); return () => { live = false; writer.current?.flushNow(); }; }, [sdk]);
  const commit = (next: EnterpriseState) => { ref.current = next; setState(next); writer.current?.schedule(KEY, () => ref.current as unknown as Record<string, unknown>); };
  const add = (kind: Kind, item: Record<string, unknown>) => { const next = sanitizeEnterprise({ ...ref.current, [kind]: [...ref.current[kind], { ...item, id: makeId(kind.slice(0,3)), createdAt: Date.now() }] }); commit(next); };
  const update = (kind: Kind, id: string, patch: Record<string, unknown>) => { const next = sanitizeEnterprise({ ...ref.current, [kind]: ref.current[kind].map((item: {id:string}) => item.id === id ? { ...item, ...patch } : item) }); commit(next); };
  const setOrganization = (organization: EnterpriseState["organization"]) => commit(sanitizeEnterprise({ ...ref.current, organization }));
  const value = useMemo(() => ({ state, ready, storageTrouble, add, update, setOrganization }), [state, ready, storageTrouble]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export function useEnterprise() { const value = useContext(Ctx); if (!value) throw new Error("useEnterprise must be used inside EnterpriseProvider"); return value; }
