"use client";

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { usePiAuth } from "@/contexts/pi-auth-context";
import { storeOf, KeyWriter } from "@/lib/bpa/store";
import {
  buildSeed,
  buildAlerts,
  buildPriorityTasks,
  healthPercent,
  makeId,
  hueFor,
  sanitizeTrees,
  sanitizeProjects,
  sanitizeZones,
  sanitizeLogs,
  sanitizeAcceptances,
  sanitizeChat,
  sanitizePrefs,
  treesToBlob,
  projectsToBlob,
  zonesToBlob,
  logsToBlob,
  acceptancesToBlob,
  chatToBlob,
  prefsToBlob,
  MAX_LOGS,
  MAX_CHAT,
  type ModuleId,
  type Tree,
  type Project,
  type Zone,
  type CareLog,
  type Acceptance,
  type ChatMsg,
  type Alert,
  type HealthId,
  type ZoneStatus,
  type CareType,
  type ApprovalStatus,
  type AcceptanceItem,
  type PriorityTask,
} from "@/lib/bpa/data";

const K = {
  trees: "bpa.trees",
  projects: "bpa.projects",
  zones: "bpa.zones",
  logs: "bpa.logs",
  acceptances: "bpa.acceptances",
  chat: "bpa.chat",
  prefs: "bpa.prefs",
} as const;

export interface Toast {
  id: string;
  text: string;
  tone: "ok" | "warn" | "info";
}

export interface TreeInput {
  code: string;
  name: string;
  species: string;
  plantedDate: string;
  location: string;
  health: HealthId;
  projectId: string | null;
}
export interface ProjectInput {
  name: string;
  location: string;
  client: string;
  startDate: string;
  progress: number;
  manager: string;
}
export interface ZoneInput {
  name: string;
  moisture: number;
  scheduleTime: string;
  durationMin: number;
  waterLiters: number;
}
export interface LogInput {
  type: CareType;
  person: string;
  note: string;
  linkType: CareLog["linkType"];
  linkId: string | null;
}
export interface AcceptanceInput {
  name: string;
  projectId: string | null;
  items: AcceptanceItem[];
  signer: string;
  note: string;
}

interface BpaContextValue {
  ready: boolean;
  storageTrouble: boolean;
  tab: ModuleId;
  setTab: (t: ModuleId) => void;

  trees: Tree[];
  projects: Project[];
  zones: Zone[];
  logs: CareLog[];
  acceptances: Acceptance[];
  chat: ChatMsg[];

  alerts: Alert[];
  healthPct: number;
  activeZoneCount: number;
  priorityTasks: PriorityTask[];

  getTree: (id: string | null) => Tree | undefined;
  getProject: (id: string | null) => Project | undefined;
  projectName: (id: string | null) => string;

  addTree: (input: TreeInput) => string;
  updateTree: (id: string, input: TreeInput) => void;
  deleteTree: (id: string) => void;

  addProject: (input: ProjectInput) => string;
  updateProject: (id: string, input: ProjectInput) => void;
  deleteProject: (id: string) => void;

  addZone: (input: ZoneInput) => void;
  updateZone: (id: string, input: ZoneInput) => void;
  setZoneStatus: (id: string, status: ZoneStatus) => void;
  toggleZone: (id: string) => void;
  deleteZone: (id: string) => void;

  addLog: (input: LogInput) => void;
  deleteLog: (id: string) => void;

  addAcceptance: (input: AcceptanceInput) => void;
  updateAcceptance: (id: string, input: AcceptanceInput) => void;
  setAcceptanceStatus: (id: string, status: ApprovalStatus) => void;
  deleteAcceptance: (id: string) => void;

  pushChat: (msg: ChatMsg) => void;
  setChat: (msgs: ChatMsg[]) => void;
  clearChat: () => void;

  toasts: Toast[];
  toast: (text: string, tone?: Toast["tone"]) => void;
}

const Ctx = createContext<BpaContextValue | undefined>(undefined);

export function BpaProvider({ children }: { children: ReactNode }) {
  const { sdk, isAuthenticated } = usePiAuth();
  const [ready, setReady] = useState(false);
  const [storageTrouble, setStorageTrouble] = useState(false);

  const [tab, setTabState] = useState<ModuleId>("dashboard");
  const [trees, setTrees] = useState<Tree[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [zones, setZones] = useState<Zone[]>([]);
  const [logs, setLogs] = useState<CareLog[]>([]);
  const [acceptances, setAcceptances] = useState<Acceptance[]>([]);
  const [chat, setChatState] = useState<ChatMsg[]>([]);
  const [toasts, setToasts] = useState<Toast[]>([]);

  const treesRef = useRef<Tree[]>([]);
  const projectsRef = useRef<Project[]>([]);
  const zonesRef = useRef<Zone[]>([]);
  const logsRef = useRef<CareLog[]>([]);
  const accRef = useRef<Acceptance[]>([]);
  const chatRef = useRef<ChatMsg[]>([]);
  const prefsRef = useRef<ModuleId>("dashboard");

  const writerRef = useRef<KeyWriter | null>(null);

  function toast(text: string, tone: Toast["tone"] = "info") {
    const id = makeId("t");
    setToasts((prev) => [...prev, { id, text, tone }]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 2600);
  }

  // load
  useEffect(() => {
    if (!isAuthenticated) return;
    let cancelled = false;
    const store = storeOf(sdk);
    const writer = new KeyWriter(store, (v) => setStorageTrouble(v));
    writerRef.current = writer;

    (async () => {
      try {
        const [rt, rp, rz, rl, ra, rc, rpref] = await Promise.all([
          store.get(K.trees),
          store.get(K.projects),
          store.get(K.zones),
          store.get(K.logs),
          store.get(K.acceptances),
          store.get(K.chat),
          store.get(K.prefs),
        ]);
        if (cancelled) return;

        const fresh = rt === null && rp === null && rz === null;
        if (fresh) {
          const seed = buildSeed();
          treesRef.current = seed.trees;
          projectsRef.current = seed.projects;
          zonesRef.current = seed.zones;
          logsRef.current = seed.logs;
          accRef.current = seed.acceptances;
          writer.schedule(K.trees, () => treesToBlob(treesRef.current), true);
          writer.schedule(K.projects, () => projectsToBlob(projectsRef.current), true);
          writer.schedule(K.zones, () => zonesToBlob(zonesRef.current), true);
          writer.schedule(K.logs, () => logsToBlob(logsRef.current), true);
          writer.schedule(K.acceptances, () => acceptancesToBlob(accRef.current), true);
        } else {
          treesRef.current = sanitizeTrees(rt);
          projectsRef.current = sanitizeProjects(rp);
          zonesRef.current = sanitizeZones(rz);
          logsRef.current = sanitizeLogs(rl);
          accRef.current = sanitizeAcceptances(ra);
        }
        chatRef.current = sanitizeChat(rc);
        prefsRef.current = sanitizePrefs(rpref).tab;

        setTrees(treesRef.current);
        setProjects(projectsRef.current);
        setZones(zonesRef.current);
        setLogs(logsRef.current);
        setAcceptances(accRef.current);
        setChatState(chatRef.current);
        setTabState(prefsRef.current);
        setReady(true);
      } catch {
        setReady(true);
      }
    })();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sdk, isAuthenticated]);

  // flush on hide
  useEffect(() => {
    const flush = () => writerRef.current?.flushNow();
    const onVis = () => {
      if (document.visibilityState === "hidden") flush();
    };
    window.addEventListener("pagehide", flush);
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.removeEventListener("pagehide", flush);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, []);

  function commitTrees(next: Tree[]) {
    treesRef.current = next;
    setTrees(next);
    writerRef.current?.schedule(K.trees, () => treesToBlob(treesRef.current), true);
  }
  function commitProjects(next: Project[]) {
    projectsRef.current = next;
    setProjects(next);
    writerRef.current?.schedule(K.projects, () => projectsToBlob(projectsRef.current), true);
  }
  function commitZones(next: Zone[], immediate = true) {
    zonesRef.current = next;
    setZones(next);
    writerRef.current?.schedule(K.zones, () => zonesToBlob(zonesRef.current), immediate);
  }
  function commitLogs(next: CareLog[]) {
    logsRef.current = next.slice(0, MAX_LOGS);
    setLogs(logsRef.current);
    writerRef.current?.schedule(K.logs, () => logsToBlob(logsRef.current), true);
  }
  function commitAcc(next: Acceptance[]) {
    accRef.current = next;
    setAcceptances(next);
    writerRef.current?.schedule(K.acceptances, () => acceptancesToBlob(accRef.current), true);
  }
  function commitChat(next: ChatMsg[]) {
    chatRef.current = next.slice(-MAX_CHAT);
    setChatState(chatRef.current);
    writerRef.current?.schedule(K.chat, () => chatToBlob(chatRef.current), false);
  }

  function setTab(t: ModuleId) {
    prefsRef.current = t;
    setTabState(t);
    writerRef.current?.schedule(K.prefs, () => prefsToBlob({ tab: prefsRef.current }), false);
  }

  // Trees
  function addTree(input: TreeInput): string {
    const id = makeId("tree");
    const t: Tree = {
      id,
      code: input.code.trim() || `C-${String(treesRef.current.length + 1).padStart(4, "0")}`,
      name: input.name.trim() || "Cây",
      species: input.species.trim(),
      plantedDate: input.plantedDate,
      location: input.location.trim(),
      health: input.health,
      hue: hueFor(input.name || id),
      projectId: input.projectId,
      createdAt: Date.now(),
    };
    commitTrees([t, ...treesRef.current]);
    toast("Đã thêm cây mới", "ok");
    return id;
  }
  function updateTree(id: string, input: TreeInput) {
    commitTrees(
      treesRef.current.map((t) =>
        t.id === id
          ? {
              ...t,
              code: input.code.trim() || t.code,
              name: input.name.trim() || t.name,
              species: input.species.trim(),
              plantedDate: input.plantedDate,
              location: input.location.trim(),
              health: input.health,
              projectId: input.projectId,
            }
          : t,
      ),
    );
    toast("Đã cập nhật", "ok");
  }
  function deleteTree(id: string) {
    commitTrees(treesRef.current.filter((t) => t.id !== id));
    toast("Đã xóa cây", "warn");
  }

  // Projects
  function addProject(input: ProjectInput): string {
    const id = makeId("prj");
    const p: Project = {
      id,
      name: input.name.trim() || "Dự án",
      location: input.location.trim(),
      client: input.client.trim(),
      startDate: input.startDate,
      progress: Math.max(0, Math.min(100, Math.round(input.progress))),
      manager: input.manager.trim(),
      createdAt: Date.now(),
    };
    commitProjects([p, ...projectsRef.current]);
    toast("Đã tạo dự án", "ok");
    return id;
  }
  function updateProject(id: string, input: ProjectInput) {
    commitProjects(
      projectsRef.current.map((p) =>
        p.id === id
          ? {
              ...p,
              name: input.name.trim() || p.name,
              location: input.location.trim(),
              client: input.client.trim(),
              startDate: input.startDate,
              progress: Math.max(0, Math.min(100, Math.round(input.progress))),
              manager: input.manager.trim(),
            }
          : p,
      ),
    );
    toast("Đã cập nhật dự án", "ok");
  }
  function deleteProject(id: string) {
    commitProjects(projectsRef.current.filter((p) => p.id !== id));
    commitTrees(treesRef.current.map((t) => (t.projectId === id ? { ...t, projectId: null } : t)));
    toast("Đã xóa dự án", "warn");
  }

  // Zones
  function addZone(input: ZoneInput) {
    const z: Zone = {
      id: makeId("zone"),
      name: input.name.trim() || "Khu tưới",
      moisture: Math.max(0, Math.min(100, Math.round(input.moisture))),
      scheduleTime: input.scheduleTime || "06:00",
      durationMin: Math.max(1, Math.round(input.durationMin)),
      waterLiters: Math.max(0, Math.round(input.waterLiters)),
      status: "tam_dung",
      enabled: true,
      createdAt: Date.now(),
    };
    commitZones([...zonesRef.current, z]);
    toast("Đã thêm khu tưới", "ok");
  }
  function updateZone(id: string, input: ZoneInput) {
    commitZones(
      zonesRef.current.map((z) =>
        z.id === id
          ? {
              ...z,
              name: input.name.trim() || z.name,
              moisture: Math.max(0, Math.min(100, Math.round(input.moisture))),
              scheduleTime: input.scheduleTime || z.scheduleTime,
              durationMin: Math.max(1, Math.round(input.durationMin)),
              waterLiters: Math.max(0, Math.round(input.waterLiters)),
            }
          : z,
      ),
    );
    toast("Đã cập nhật khu tưới", "ok");
  }
  function setZoneStatus(id: string, status: ZoneStatus) {
    commitZones(zonesRef.current.map((z) => (z.id === id ? { ...z, status } : z)));
  }
  function toggleZone(id: string) {
    commitZones(
      zonesRef.current.map((z) => {
        if (z.id !== id) return z;
        if (z.status === "loi") return z;
        const nextEnabled = !z.enabled;
        return { ...z, enabled: nextEnabled, status: nextEnabled ? "tuoi" : "tam_dung" };
      }),
    );
  }
  function deleteZone(id: string) {
    commitZones(zonesRef.current.filter((z) => z.id !== id));
    toast("Đã xóa khu tưới", "warn");
  }

  // Logs
  function addLog(input: LogInput) {
    const l: CareLog = {
      id: makeId("log"),
      type: input.type,
      person: input.person.trim(),
      at: Date.now(),
      note: input.note.trim(),
      linkType: input.linkType,
      linkId: input.linkId,
      createdAt: Date.now(),
    };
    commitLogs([l, ...logsRef.current]);
    toast("Đã ghi nhật ký", "ok");
  }
  function deleteLog(id: string) {
    commitLogs(logsRef.current.filter((l) => l.id !== id));
    toast("Đã xóa nhật ký", "warn");
  }

  // Acceptances
  function addAcceptance(input: AcceptanceInput) {
    const a: Acceptance = {
      id: makeId("acc"),
      name: input.name.trim() || "Biên bản nghiệm thu",
      projectId: input.projectId,
      items: input.items,
      status: "cho_duyet",
      signer: input.signer.trim(),
      note: input.note.trim(),
      at: Date.now(),
      createdAt: Date.now(),
    };
    commitAcc([a, ...accRef.current]);
    toast("Đã tạo biên bản", "ok");
  }
  function updateAcceptance(id: string, input: AcceptanceInput) {
    commitAcc(
      accRef.current.map((a) =>
        a.id === id
          ? {
              ...a,
              name: input.name.trim() || a.name,
              projectId: input.projectId,
              items: input.items,
              signer: input.signer.trim(),
              note: input.note.trim(),
            }
          : a,
      ),
    );
    toast("Đã cập nhật biên bản", "ok");
  }
  function setAcceptanceStatus(id: string, status: ApprovalStatus) {
    commitAcc(accRef.current.map((a) => (a.id === id ? { ...a, status } : a)));
    toast(status === "da_duyet" ? "Đã phê duyệt" : status === "tu_choi" ? "Đã từ chối" : "Chuyển chờ duyệt", status === "tu_choi" ? "warn" : "ok");
  }
  function deleteAcceptance(id: string) {
    commitAcc(accRef.current.filter((a) => a.id !== id));
    toast("Đã xóa biên bản", "warn");
  }

  // Chat
  function pushChat(msg: ChatMsg) {
    commitChat([...chatRef.current, msg]);
  }
  function setChat(msgs: ChatMsg[]) {
    commitChat(msgs);
  }
  function clearChat() {
    commitChat([]);
    toast("Đã xóa hội thoại", "warn");
  }

  const alerts = useMemo(() => buildAlerts(trees, zones), [trees, zones]);
  const healthPct = useMemo(() => healthPercent(trees), [trees]);
  const activeZoneCount = useMemo(() => zones.filter((z) => z.status === "tuoi").length, [zones]);
  const priorityTasks = useMemo(() => buildPriorityTasks(trees, zones, projects), [trees, zones, projects]);

  const value: BpaContextValue = {
    ready,
    storageTrouble,
    tab,
    setTab,
    trees,
    projects,
    zones,
    logs,
    acceptances,
    chat,
    alerts,
    healthPct,
    activeZoneCount,
    priorityTasks,
    getTree: (id) => (id ? trees.find((t) => t.id === id) : undefined),
    getProject: (id) => (id ? projects.find((p) => p.id === id) : undefined),
    projectName: (id) => (id ? projects.find((p) => p.id === id)?.name ?? "—" : "Không thuộc dự án"),
    addTree,
    updateTree,
    deleteTree,
    addProject,
    updateProject,
    deleteProject,
    addZone,
    updateZone,
    setZoneStatus,
    toggleZone,
    deleteZone,
    addLog,
    deleteLog,
    addAcceptance,
    updateAcceptance,
    setAcceptanceStatus,
    deleteAcceptance,
    pushChat,
    setChat,
    clearChat,
    toasts,
    toast,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useBpa() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useBpa must be used within BpaProvider");
  return ctx;
}
